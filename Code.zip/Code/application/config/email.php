<?php 
$config['email_config'] = array(
                'mailtype' => 'HTML',
                'protocol' => 'SMTP',
                'smtp_host' => 'ssl://smtp.titan.email',
                'smtp_port' => '465',
                'smtp_user' => 'pms@mobipixels.com',
                'smtp_pass' => 'mobipixels123',
                'charset' => 'utf-8',
                'newline' => '\r\n',
            ); 

?>