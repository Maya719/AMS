<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    <ul class="navbar-nav mr-auto">
      <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
    </ul>
  <ul class="navbar-nav navbar-right">
  <?php 
    $notifications = get_notifications();
  ?>
    <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg <?=$notifications?'beep':''?>"><i class="far fa-bell"></i></a>
      <div class="dropdown-menu dropdown-list dropdown-menu-right">
        <div class="dropdown-header">
          <?=$this->lang->line('notifications')?$this->lang->line('notifications'):'Notifications'?>
        </div>
        <div class="dropdown-list-content dropdown-list-icons">
        <?php if($notifications){ 
          foreach($notifications as $notification){
        ?>

          <a href="<?=$notification['notification_url']?>" class="dropdown-item dropdown-item-unread">
            <?php if(isset($notification['profile']) && !empty($notification['profile'])){ ?>
              <figure class="dropdown-item-icon avatar avatar-m bg-transparent">
                <img src="<?=base_url(UPLOAD_PROFILE.''.htmlspecialchars($notification['profile']))?>" alt="<?=htmlspecialchars($notification['first_name'])?> <?=htmlspecialchars($notification['last_name'])?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=htmlspecialchars($notification['first_name'])?> <?=htmlspecialchars($notification['last_name'])?>">
              </figure>
            <?php }else{ ?>
              <figure class="dropdown-item-icon avatar avatar-m bg-primary text-white" data-initial="<?=mb_substr(htmlspecialchars($notification['first_name']), 0, 1, "utf-8").''.mb_substr(htmlspecialchars($notification['last_name']), 0, 1, "utf-8")?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=htmlspecialchars($notification['first_name'])?> <?=htmlspecialchars($notification['last_name'])?>">
              </figure>
            <?php } ?>
            <div class="dropdown-item-desc  ml-2">
              <?=$notification['notification']?>
              <div class="time text-primary"><?=time_elapsed_string($notification['created'])?></div>
            </div>
          </a>
        <?php } }else{ ?>
          <a class="dropdown-item dropdown-item-unread">
          <div class="dropdown-item-desc  ml-2">
            <?=$this->lang->line('no_new_notifications')?$this->lang->line('no_new_notifications'):'No new notifications.'?>
          </div>
          </a>
        <?php } ?>
        </div>
        <div class="dropdown-footer text-center">
          <a href="<?=base_url('notifications')?>"><?=$this->lang->line('view_all')?$this->lang->line('view_all'):'View All'?> <i class="fas fa-chevron-right"></i></a>
        </div>
      </div>
    </li>

    <li class="dropdown">
      <a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg">
      <i class="fa fa-language"></i>
      </a>
      <div class="dropdown-menu dropdown-menu-right">
        <?php $languages = get_languages();
          if($languages){
          foreach($languages as $language){  ?>
            <a href="<?=base_url('languages/change/'.$language['language'])?>" class="dropdown-item <?=$language['language']==$this->session->userdata('lang') || ($language['language']=='english' && !$this->session->userdata('lang'))?'active':''?>">
              <?=ucfirst($language['language'])?>
            </a>
        <?php } } ?>
      </div>
    </li>


    <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
      <?php if(isset($current_user->profile) && !empty($current_user->profile)){ ?>
          <img alt="image" src="<?=base_url(UPLOAD_PROFILE.''.htmlspecialchars($current_user->profile))?>" class="rounded-circle mr-1">
      <?php }else{ ?>
          <figure class="avatar mr-2 avatar-sm bg-danger text-white" data-initial="<?=mb_substr(htmlspecialchars($current_user->first_name), 0, 1, "utf-8").''.mb_substr(htmlspecialchars($current_user->last_name), 0, 1, "utf-8")?>"></figure>
      <?php } ?>
      <div class="d-sm-none d-lg-inline-block"><?=htmlspecialchars($current_user->first_name)?> <?=htmlspecialchars($current_user->last_name)?></div></a>
      <div class="dropdown-menu dropdown-menu-right">
        <?php
          if($this->ion_auth->is_admin()){
            $my_plan = get_current_plan(); ?>
          <div class="dropdown-title">
            <h6 class="text-danger"><?=$my_plan['title']?></h6>
          </div>
        <?php  }
        ?>
        
        <a href="<?=base_url('users/profile')?>" class="dropdown-item has-icon <?=(current_url() == base_url('users/profile'))?'active':''?>">
          <i class="far fa-user"></i> <?=$this->lang->line('profile')?$this->lang->line('profile'):'Profile'?>
        </a>
        
        <?php if($this->ion_auth->in_group(4)){ ?>
          <a href="<?=base_url('users/company')?>" class="dropdown-item has-icon <?=(current_url() == base_url('users/company'))?'active':''?>">
            <i class="far fa-copyright"></i> <?=$this->lang->line('company')?$this->lang->line('company'):'Company'?>
          </a>
        <?php } ?>

        <div class="dropdown-divider"></div>
        <a href="<?=base_url('auth/logout')?>" class="dropdown-item has-icon text-danger">
          <i class="fas fa-sign-out-alt"></i> <?=$this->lang->line('logout')?$this->lang->line('logout'):'Logout'?>
        </a>
      </div>
    </li>
  </ul>
</nav>
<div class="main-sidebar sidebar-style-2">
  <aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="<?=base_url()?>"><img class="navbar-logos" alt="Logo" src="<?=base_url('assets/uploads/logos/'.full_logo())?>"></a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="<?=base_url()?>"><img class="navbar-logos" alt="Logo Half" src="<?=base_url('assets/uploads/logos/'.half_logo())?>"></a>
    </div>
    <ul class="sidebar-menu">
      <li <?= (current_url() == base_url('/') || current_url() == base_url('home'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url()?>"><i class="fas fa-home text-danger"></i> <span><?=$this->lang->line('dashboard')?$this->lang->line('dashboard'):'Dashboard'?></span></a></li>
      
      <?php if (($this->ion_auth->is_admin() || permissions('project_view')) && !$this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('projects') || $this->uri->segment(2) == 'detail')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('projects')?>"><i class="fas fa-cubes text-info"></i> <span><?=$this->lang->line('projects')?$this->lang->line('projects'):'Projects'?></span></a></li>
      <?php } ?>

      <?php if (($this->ion_auth->is_admin() || permissions('task_view')) && !$this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('projects/tasks')  || $this->uri->segment(2) == 'tasks')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('projects/tasks')?>"><i class="fas fa-layer-group text-dark"></i> <span><?=$this->lang->line('tasks')?$this->lang->line('tasks'):'Tasks'?></span></a></li>
      <?php } ?>

      <?php if ($this->ion_auth->is_admin() || $this->ion_auth->in_group(4)){ ?>  
        <li <?= ((current_url() == base_url('invoices') || $this->uri->segment(1) == 'invoices') && $this->uri->segment(2) != 'payments')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('invoices')?>"><i class="fas fa-file-invoice-dollar text-success"></i> <span><?=$this->lang->line('invoices')?$this->lang->line('invoices'):'Invoices'?></span></a></li>
      <?php } ?>

      <?php if ($this->ion_auth->is_admin() || $this->ion_auth->in_group(4)){ ?>  
        <li <?= (current_url() == base_url('invoices/payments') || $this->uri->segment(2) == 'payments')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('invoices/payments')?>"><i class="fas fa-credit-card text-warning"></i> <span><?=$this->lang->line('payments')?$this->lang->line('payments'):'Payments'?></span></a></li>
      <?php } ?>

      <?php if (($this->ion_auth->is_admin() || permissions('client_view')) && !$this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('users/client'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('users/client')?>"><i class="fas fa-handshake text-primary"></i> <span><?=$this->lang->line('clients')?$this->lang->line('clients'):'Clients'?></span></a></li>
      <?php } ?>

      <?php if (($this->ion_auth->is_admin() || permissions('todo_view')) && !$this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('todo'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('todo')?>"><i class="fas fa-tasks text-info"></i> <span><?=$this->lang->line('todo')?$this->lang->line('todo'):'ToDo'?></span></a></li>
      <?php } ?>

      <?php if (($this->ion_auth->is_admin() || permissions('notes_view')) && !$this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('notes'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('notes')?>"><i class="fas fa-sticky-note text-danger"></i> <span><?=$this->lang->line('notes')?$this->lang->line('notes'):'Notes'?></span></a></li>
      <?php } ?>

      <?php if (($this->ion_auth->is_admin() || permissions('chat_view')) && !$this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('chat'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('chat')?>"><i class="fas fa-comment-alt text-success"></i> <span><?=$this->lang->line('chat')?$this->lang->line('chat'):'Chat'?></span></a></li>
      <?php } ?>

      <?php if (($this->ion_auth->is_admin() || $this->ion_auth->in_group(3))){ ?>  
        <li <?= (current_url() == base_url('plans'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('plans')?>"><i class="fas fa-dollar-sign text-warning"></i> <span><?=$this->lang->line('subscription_plans')?$this->lang->line('subscription_plans'):'Plans'?></span></a></li>
      <?php } ?>
      
      <?php if ($this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('plans/orders'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('plans/orders')?>"><i class="fas fa-shopping-cart text-dark"></i> <span><?=$this->lang->line('orders')?$this->lang->line('orders'):'Orders'?></span></a></li>
      <?php } ?>

      <?php if ($this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('plans/offline-requests'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('plans/offline-requests')?>"><i class="fas fa-hand-holding-usd text-primary"></i> <span><?=$this->lang->line('offline_requests')?$this->lang->line('offline_requests'):'Offline Requests'?></span></a></li>
      <?php } ?>

      <?php if ($this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('plans/transactions'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('plans/transactions')?>"><i class="fas fa-money-bill-alt text-success"></i> <span><?=$this->lang->line('transactions')?$this->lang->line('transactions'):'Transactions'?></span></a></li>
      <?php } ?>

      <?php if ($this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('users/saas'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('users/saas')?>"><i class="fas fa-users-cog text-danger"></i> <span><?=$this->lang->line('users_and_plan')?$this->lang->line('users_and_plan'):'Users and Plan'?></span></a></li>
      <?php } ?>

      <?php if ($this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('users'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('users')?>"><i class="fas fa-user-tie text-warning"></i> <span><?=$this->lang->line('saas_admins')?$this->lang->line('saas_admins'):'SaaS Admins'?></span></a></li>
      <?php } ?>

      <?php if (($this->ion_auth->is_admin() || permissions('user_view')) && !$this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('users'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('users')?>"><i class="fas fa-user-friends text-dark"></i> <span><?=$this->lang->line('users')?$this->lang->line('users'):'Team Members'?></span></a></li>
      <?php } ?>

      <?php if ($this->ion_auth->in_group(3)){ ?>  
        <li <?= (current_url() == base_url('front/landing'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('front/landing')?>"><i class="fas fa-puzzle-piece text-dark"></i> <span><?=$this->lang->line('frontend')?$this->lang->line('frontend'):'Frontend'?></span></a></li>
      <?php } ?>
      
      <?php if ($this->ion_auth->is_admin() || $this->ion_auth->in_group(3)){ ?>           
        <li class="dropdown <?=(current_url() == base_url('settings') || current_url() == base_url('settings/payment') || current_url() == base_url('settings/email') || current_url() == base_url('settings/user-permissions') || current_url() == base_url('settings/update') || current_url() == base_url('languages') || current_url() == base_url('settings/company') || current_url() == base_url('settings/taxes'))?'active':''?>">
        <a class="nav-link has-dropdown" href="#"><i class="fas fa-pencil-ruler text-primary"></i> 
        <span><?=$this->lang->line('settings')?$this->lang->line('settings'):'Settings'?></span></a>
          <ul class="dropdown-menu">
            <li <?= (current_url() == base_url('settings'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings')?>"><?=$this->lang->line('general')?$this->lang->line('general'):'General'?></a></li>
            <li <?= (current_url() == base_url('settings/payment'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/payment')?>"><?=$this->lang->line('payment_gateway')?$this->lang->line('payment_gateway'):'Payment Gateway'?></a></li> 
            <?php if ($this->ion_auth->in_group(3)){ ?> 
              <li <?= (current_url() == base_url('settings/email'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/email')?>"><?=$this->lang->line('email')?$this->lang->line('email'):'Email'?></a></li>
              <li <?= (current_url() == base_url('languages'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('languages')?>"><?=$this->lang->line('languages')?$this->lang->line('languages'):'Languages'?></a></li>
              <li <?= (current_url() == base_url('settings/update'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/update')?>"><?=$this->lang->line('update')?$this->lang->line('update'):'Update'?></a></li>
              <?php }else{ ?>
              <li <?= (current_url() == base_url('settings/company'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/company')?>"><?=$this->lang->line('company')?$this->lang->line('company'):'Company'?></a></li>
              <li <?= (current_url() == base_url('settings/taxes'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/taxes')?>"><?=$this->lang->line('taxes')?$this->lang->line('taxes'):'Taxes'?></a></li>
              <li <?= (current_url() == base_url('settings/user-permissions'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/user-permissions')?>"><?=$this->lang->line('user_permissions')?$this->lang->line('user_permissions'):'User Permissions'?></a></li>
              <?php } ?>
          </ul>
        </li>
      <?php } ?>
      
    </ul>
  </aside>
</div>