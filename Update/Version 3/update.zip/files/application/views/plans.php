<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('includes/head'); ?>
</head>
<body>
  <div id="app">
    <div class="main-wrapper">
      <?php $this->load->view('includes/navbar'); ?>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <div class="section-header-back">
              <a href="<?=base_url()?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
            </div>
            <h1>
            <?php
              echo $this->lang->line('subscription_plans')?$this->lang->line('subscription_plans'):'Plans';
              if($this->ion_auth->in_group(3)){
                echo ' <a href="#" id="modal-add-plan" class="btn btn-sm btn-icon icon-left btn-primary"><i class="fas fa-plus"></i>'.($this->lang->line('create')?$this->lang->line('create'):'Create').'</a>';
              }
            ?>
            </h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="<?=base_url()?>"><?=$this->lang->line('dashboard')?$this->lang->line('dashboard'):'Dashboard'?></a></div>
              <div class="breadcrumb-item">
              <?=$this->lang->line('subscription_plans')?$this->lang->line('subscription_plans'):'Plans'?>
              </div>
            </div>
          </div>
          <div class="section-body">
            
            <div class="row align-items-center justify-content-center">

              <?php if($this->ion_auth->in_group(3)){ ?>
                
                  <div class="col-md-12">
                    <div class="card card-primary">
                      <div class="card-body"> 
                        <table class='table-striped' id='plans_list'
                          data-toggle="table"
                          data-url="<?=base_url('plans/get_plans')?>"
                          data-click-to-select="true"
                          data-side-pagination="server"
                          data-pagination="false"
                          data-page-list="[5, 10, 20, 50, 100, 200]"
                          data-search="false" data-show-columns="false"
                          data-show-refresh="false" data-trim-on-search="false"
                          data-sort-name="id" data-sort-order="asc"
                          data-mobile-responsive="true"
                          data-toolbar="" data-show-export="false"
                          data-maintain-selected="true"
                          data-export-types='["txt","excel"]'
                          data-export-options='{
                            "fileName": "plans-list",
                            "ignoreColumn": ["state"] 
                          }'
                          data-query-params="queryParams">
                          <thead>
                            <tr>
                              <th data-field="title" data-sortable="true"><?=$this->lang->line('title')?$this->lang->line('title'):'Title'?></th>
                              <th data-field="price" data-sortable="true"><?=$this->lang->line('price_usd')?$this->lang->line('price_usd').' - '.get_saas_currency('currency_code'):'Price - '.get_saas_currency('currency_code')?></th>
                              <th data-field="billing_type" data-sortable="true"><?=$this->lang->line('billing_type')?$this->lang->line('billing_type'):'Billing Type'?></th>
                              <th data-field="features" data-sortable="true"><?=$this->lang->line('features')?$this->lang->line('features'):'Features'?></th>
                              <th data-field="action" data-sortable="false"><?=$this->lang->line('action')?$this->lang->line('action'):'Action'?></th>
                            </tr>
                          </thead>
                        </table>
                      </div>
                    </div>
                  </div>
              <?php }else{ 
                $my_plan = get_current_plan();
                if($this->ion_auth->is_admin()){ 
                if($my_plan && ($my_plan['expired'] == 0 || $my_plan['end_date'] <= date('Y-m-d',date(strtotime("+".alert_days()." day", strtotime(date('Y-m-d'))))))){ 
              ?>
                  <div class="col-md-12 mb-4">
                    <div class="hero text-white bg-danger">
                      <div class="hero-inner">
                        <h2><?=$this->lang->line('alert')?$this->lang->line('alert'):'Alert...'?></h2>
                        <?php 
                          if($my_plan['expired'] == 0){ 
                        ?>
                          <p class="lead"><?=$this->lang->line('your_subscription_plan_has_been_expired_on_date')?$this->lang->line('your_subscription_plan_has_been_expired_on_date'):'Your subscription plan has been expired on date'?> <?=htmlspecialchars(format_date($my_plan["end_date"],system_date_format()))?> <?=$this->lang->line('renew_it_now')?$this->lang->line('renew_it_now'):'Renew it now.'?></p>
                        <?php }elseif($my_plan['end_date'] <= date('Y-m-d',date(strtotime("+".alert_days()." day", strtotime(date('Y-m-d')))))){ ?>
                          <p class="lead"><?=$this->lang->line('your_current_subscription_plan_is_expiring_on_date')?$this->lang->line('your_current_subscription_plan_is_expiring_on_date'):'Your current subscription plan is expiring on date'?> <?=htmlspecialchars(format_date($my_plan["end_date"],system_date_format()))?>.</p>
                        <?php } ?>
                      </div>
                    </div>
                  </div>
              <?php } } 
                foreach($plans as $plan){
              ?>
                  <div class="col-md-4">
                    <div class="pricing card <?=$my_plan['plan_id'] == $plan['id']?'pricing-highlight':''?>">
                      <div class="pricing-title">
                        <?=htmlspecialchars($plan['title'])?> 

                        <?php if($my_plan['plan_id'] == $plan['id']){ ?>
                          <i class="fas fa-question-circle text-success" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('this_is_your_current_active_plan_and_expiring_on_date')?$this->lang->line('this_is_your_current_active_plan_and_expiring_on_date'):'This is your current active plan and expiring on date'?> <?=htmlspecialchars(format_date($my_plan["end_date"],system_date_format()))?>."></i>
                        <?php } ?>

                      </div>
                      <div class="pricing-padding">
                        <div class="pricing-price">
                          <div><?=htmlspecialchars(get_saas_currency('currency_symbol'))?> <?=htmlspecialchars($plan['price'])?></div>
                          <div>
                            <?php
                              if($plan["billing_type"] == 'Monthly'){
                                echo $this->lang->line('monthly')?$this->lang->line('monthly'):'Monthly';
                              }else{
                                echo $this->lang->line('yearly')?$this->lang->line('yearly'):'Yearly';
                              } 
                            ?>
                          </div>
                        </div>
                        <div class="pricing-details">
                          <div class="pricing-item">
                            <div class="pricing-item-label mr-1 font-weight-bold"><?=$this->lang->line('projects')?$this->lang->line('projects'):'Projects'?></div>
                            <div class="badge badge-primary"><?=$plan['projects']<0?$this->lang->line('unlimited')?$this->lang->line('unlimited'):'Unlimited':htmlspecialchars($plan['projects'])?></div>
                          </div>
                          <div class="pricing-item">
                            <div class="pricing-item-label mr-1 font-weight-bold"><?=$this->lang->line('tasks')?$this->lang->line('tasks'):'Tasks'?></div>
                            <div class="badge badge-primary"><?=$plan['tasks']<0?$this->lang->line('unlimited')?$this->lang->line('unlimited'):'Unlimited':htmlspecialchars($plan['tasks'])?></div>
                          </div>
                          <div class="pricing-item">
                            <div class="pricing-item-label mr-1 font-weight-bold"><?=$this->lang->line('users')?$this->lang->line('users'):'Team Members'?> <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('including_admins_clients_and_users')?$this->lang->line('including_admins_clients_and_users'):'Including Admins, Clients and Users.'?>"></i></div>
                            <div class="badge badge-primary"><?=$plan['users']<0?$this->lang->line('unlimited')?$this->lang->line('unlimited'):'Unlimited':htmlspecialchars($plan['users'])?></div>
                          </div>
                        </div>
                      </div>
                      <div class="pricing-cta">
                        <a href="#" class="payment-button" data-amount="<?=htmlspecialchars($plan['price'])?>" data-id="<?=htmlspecialchars($plan['id'])?>"><?=$my_plan['plan_id'] == $plan['id']?($this->lang->line('renew_plan')?$this->lang->line('renew_plan'):'Renew Plan.'):($this->lang->line('subscribe')?$this->lang->line('subscribe'):'Subscribe')?> <i class="fas fa-arrow-right"></i></a>
                      </div>
                    </div>
                  </div>
              <?php } } ?>
            </div>
          </div>
          <div class="row d-none" id="payment-div">
            <div id="paypal-button" class="col-md-8 mx-auto paymet-box"></div>
            <?php if(get_stripe_secret_key() && get_stripe_publishable_key()){ ?>
              <button id="stripe-button" class="col-md-8 btn mx-auto paymet-box">
                <img src="<?=base_url('assets/img/stripe.png')?>" width="14%" alt="Stripe">
              </button>
            <?php } ?>
            <?php if(get_razorpay_key_id()){ ?>
              <button id="razorpay-button" class="col-md-8 btn mx-auto paymet-box">
                  <img src="<?=base_url('assets/img/razorpay.png')?>" width="27%" alt="Stripe">
              </button>
            <?php } ?>
            <?php if(get_offline_bank_transfer()){ ?>
              <button id="offline-button" class="col-md-8 btn btn-danger mx-auto">
              <?=$this->lang->line('offline_bank_transfer')?$this->lang->line('offline_bank_transfer'):'Offline / Bank Transfer'?>
              </button>
            <?php } ?>
          </div>
        </section>
      </div>
      <?php $this->load->view('includes/footer'); ?>
    </div>
  </div>


<form action="<?=base_url('plans/create')?>" method="POST" class="modal-part" id="modal-add-plan-part" data-title="<?=$this->lang->line('create')?$this->lang->line('create'):'Create'?>" data-btn="<?=$this->lang->line('create')?$this->lang->line('create'):'Create'?>">
  <div class="row">
    <div class="form-group col-md-12">
      <label><?=$this->lang->line('title')?$this->lang->line('title'):'Title'?><span class="text-danger">*</span></label>
      <input type="text" name="title" class="form-control" required="">
    </div>
    <div class="form-group col-md-6">
      <label><?=$this->lang->line('price_usd')?$this->lang->line('price_usd').' - '.get_saas_currency('currency_code'):'Price - '.get_saas_currency('currency_code')?><span class="text-danger">*</span></label>
      <input type="number" name="price" class="form-control">
    </div>
    
    <div class="form-group col-md-6">
      <label><?=$this->lang->line('billing_type')?$this->lang->line('billing_type'):'Billing Type'?><span class="text-danger">*</span></label>
      <select name="billing_type" class="form-control select2">
        <option value="Monthly"><?=$this->lang->line('monthly')?$this->lang->line('monthly'):'Monthly'?></option>
        <option value="Yearly"><?=$this->lang->line('yearly')?$this->lang->line('yearly'):'Yearly'?></option>
      </select>
    </div>

    <div class="form-group col-md-6">
      <label><?=$this->lang->line('projects')?$this->lang->line('projects'):'Projects'?><span class="text-danger">*</span></label>
      <input type="number" name="projects"  class="form-control">
    </div>

    <div class="form-group col-md-6">
      <label><?=$this->lang->line('tasks')?$this->lang->line('tasks'):'Tasks'?><span class="text-danger">*</span></label>
      <input type="number" name="tasks"  class="form-control">
    </div>
    <div class="form-group col-md-6">
      <label><?=$this->lang->line('users')?$this->lang->line('users'):'Team Members'?><span class="text-danger">*</span></label>
      <input type="number" name="users"  class="form-control">
    </div>
    <div class="form-group col-md-12">
      <small class="form-text text-muted">
      <?=$this->lang->line('set_value_in_minus_to_make_it_unlimited')?$this->lang->line('set_value_in_minus_to_make_it_unlimited'):'Set value in minus (-1) to make it Unlimited.'?>
      </small>
    </div>
  </div>
</form>

<div id="modal-edit-plan"></div>
<form action="<?=base_url('plans/edit')?>" method="POST" class="modal-part" id="modal-edit-plan-part" data-title="<?=$this->lang->line('edit')?$this->lang->line('edit'):'Edit'?>" data-btn="<?=$this->lang->line('update')?$this->lang->line('update'):'Update'?>">
  <div class="row">
    <div class="form-group col-md-12">
      <label><?=$this->lang->line('title')?$this->lang->line('title'):'Title'?><span class="text-danger">*</span></label>
      <input type="hidden" name="update_id" id="update_id">
      <input type="text" name="title" id="title" class="form-control" required="">
    </div>
    <div class="form-group col-md-6">
      <label><?=$this->lang->line('price_usd')?$this->lang->line('price_usd').' - '.get_saas_currency('currency_code'):'Price - '.get_saas_currency('currency_code')?><span class="text-danger">*</span></label>
      <input type="number" name="price" id="price" class="form-control">
    </div>
    
    <div class="form-group col-md-6">
      <label><?=$this->lang->line('billing_type')?$this->lang->line('billing_type'):'Billing Type'?>v<span class="text-danger">*</span></label>
      <select name="billing_type" id="billing_type" class="form-control select2">
        <option value="Monthly"><?=$this->lang->line('monthly')?$this->lang->line('monthly'):'Monthly'?></option>
        <option value="Yearly"><?=$this->lang->line('yearly')?$this->lang->line('yearly'):'Yearly'?></option>
      </select>
    </div>

    <div class="form-group col-md-6">
      <label><?=$this->lang->line('projects')?$this->lang->line('projects'):'Projects'?><span class="text-danger">*</span></label>
      <input type="number" name="projects" id="projects" class="form-control">
    </div>

    <div class="form-group col-md-6">
      <label><?=$this->lang->line('tasks')?$this->lang->line('tasks'):'Tasks'?><span class="text-danger">*</span></label>
      <input type="number" name="tasks" id="tasks" class="form-control">
    </div>
    <div class="form-group col-md-6">
      <label><?=$this->lang->line('users')?$this->lang->line('users'):'Team Members'?><span class="text-danger">*</span></label>
      <input type="number" name="users" id="users" class="form-control">
    </div>
    <div class="form-group col-md-12">
      <small class="form-text text-muted">
      <?=$this->lang->line('set_value_in_minus_to_make_it_unlimited')?$this->lang->line('set_value_in_minus_to_make_it_unlimited'):'Set value in minus (-1) to make it Unlimited.'?>
      </small>
    </div>
  </div>
</form>

<?php $this->load->view('includes/js'); ?>

<script>
paypal_client_id = "<?=get_payment_paypal()?>";
get_stripe_publishable_key = "<?=get_stripe_publishable_key()?>";
razorpay_key_id = "<?=get_razorpay_key_id()?>";
offline_bank_transfer = "<?=get_offline_bank_transfer()?>";
</script>

<?php if(get_payment_paypal()){ ?>
<script src="https://www.paypal.com/sdk/js?client-id=<?=get_payment_paypal()?>&currency=<?=get_saas_currency('currency_code')?>"></script>
<?php } ?>

<?php if(get_stripe_publishable_key()){ ?>
<script src="https://js.stripe.com/v3/"></script>
<?php } ?>


<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script src="<?=base_url('assets/js/page/payment.js');?>"></script>
</body>
</html>
