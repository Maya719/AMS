<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('includes/head'); ?>
</head>
<body>
  <div id="app">
    <div class="main-wrapper">
      <?php $this->load->view('includes/navbar'); ?>
        <div class="main-content">
          <section class="section">
            <div class="section-header">
              <div class="section-header-back">
                <a href="<?=base_url()?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
              </div>
              <h1><?=$this->lang->line('frontend')?$this->lang->line('frontend'):'Frontend'?></h1>
              <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?=base_url()?>"><?=$this->lang->line('dashboard')?$this->lang->line('dashboard'):'Dashboard'?></a></div>
                <div class="breadcrumb-item"><?=$this->lang->line('frontend')?$this->lang->line('frontend'):'Frontend'?></div>
              </div>
            </div>

            <div class="section-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="card card-primary" id="settings-card">
                    



                    <form action="<?=base_url('settings/save-front-setting')?>" method="POST" id="setting-form">
                      <div class="card-body row">
                        <div class="col-md-12">
                          <div class="card-header">
                            <h4 class="card-title"><?=$this->lang->line('frontend_customization')?$this->lang->line('frontend_customization'):'Frontend Customization'?></h4>
                          </div>
                          <div class="form-group col-md-12">
                              <label class="d-block mt-3"><?=$this->lang->line('enable_or_disable_sections')?$this->lang->line('enable_or_disable_sections'):'Enable OR Disable Sections'?> <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?=$this->lang->line('disable_landing_page_option_to_disable_whole_frontend')?$this->lang->line('disable_landing_page_option_to_disable_whole_frontend'):'Disable Landing Page option to Disable whole frontend.'?>"></i></label>

                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="landing_page" name="landing_page" value="<?=(isset($frontend_permissions->landing_page) && !empty($frontend_permissions->landing_page))?$frontend_permissions->landing_page:0?>" <?=(isset($frontend_permissions->landing_page) && !empty($frontend_permissions->landing_page) && $frontend_permissions->landing_page == 1)?'checked':''?>>
                                <label class="form-check-label" for="landing_page"><?=$this->lang->line('landing_page')?$this->lang->line('landing_page'):'Landing Page'?></label>
                              </div>

                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="home" name="home" value="<?=(isset($frontend_permissions->home) && !empty($frontend_permissions->home))?$frontend_permissions->home:0?>" <?=(isset($frontend_permissions->home) && !empty($frontend_permissions->home) && $frontend_permissions->home == 1)?'checked':''?>>
                                <label class="form-check-label" for="home"><?=$this->lang->line('home')?$this->lang->line('home'):'Home'?></label>
                              </div>

                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="features" name="features" value="<?=(isset($frontend_permissions->features) && !empty($frontend_permissions->features))?$frontend_permissions->features:0?>" <?=(isset($frontend_permissions->features) && !empty($frontend_permissions->features) && $frontend_permissions->features == 1)?'checked':''?>>
                                <label class="form-check-label" for="features"><?=$this->lang->line('features')?$this->lang->line('features'):'Features'?></label>
                              </div>
                              
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="subscription_plans" name="subscription_plans" value="<?=(isset($frontend_permissions->subscription_plans) && !empty($frontend_permissions->subscription_plans))?$frontend_permissions->subscription_plans:0?>" <?=(isset($frontend_permissions->subscription_plans) && !empty($frontend_permissions->subscription_plans) && $frontend_permissions->subscription_plans == 1)?'checked':''?>>
                                <label class="form-check-label" for="subscription_plans"><?=$this->lang->line('subscription_plans')?$this->lang->line('subscription_plans'):'Plans'?></label>
                              </div>
                              
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="contact" name="contact" value="<?=(isset($frontend_permissions->contact) && !empty($frontend_permissions->contact))?$frontend_permissions->contact:0?>" <?=(isset($frontend_permissions->contact) && !empty($frontend_permissions->contact) && $frontend_permissions->contact == 1)?'checked':''?>>
                                <label class="form-check-label" for="contact"><?=$this->lang->line('contact_form')?$this->lang->line('contact_form'):'Contact Form'?></label>
                              </div>

                              
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="about" name="about" value="<?=(isset($frontend_permissions->about) && !empty($frontend_permissions->about))?$frontend_permissions->about:0?>" <?=(isset($frontend_permissions->about) && !empty($frontend_permissions->about) && $frontend_permissions->about == 1)?'checked':''?>>
                                <label class="form-check-label" for="about">About Us</label>
                              </div>

                              
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="privacy" name="privacy" value="<?=(isset($frontend_permissions->privacy) && !empty($frontend_permissions->privacy))?$frontend_permissions->privacy:0?>" <?=(isset($frontend_permissions->privacy) && !empty($frontend_permissions->privacy) && $frontend_permissions->privacy == 1)?'checked':''?>>
                                <label class="form-check-label" for="privacy">Privacy Policy</label>
                              </div>

                              
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="terms" name="terms" value="<?=(isset($frontend_permissions->terms) && !empty($frontend_permissions->terms))?$frontend_permissions->terms:0?>" <?=(isset($frontend_permissions->terms) && !empty($frontend_permissions->terms) && $frontend_permissions->terms == 1)?'checked':''?>>
                                <label class="form-check-label" for="terms">Terms and Conditions</label>
                              </div>

                          </div>


                          
                        </div>

                      </div>
                        <div class="card-footer bg-whitesmoke text-md-right">
                          <button class="btn btn-primary savebtn"><?=$this->lang->line('save_changes')?$this->lang->line('save_changes'):'Save Changes'?></button>
                        </div>
                      <div class="result"></div>
                    </form>



                  </div>
                </div>

                <div class="col-md-12 <?=(isset($frontend_permissions->home) && !empty($frontend_permissions->home) && $frontend_permissions->home == 1)?'':'d-none'?>" id="home_div">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h4 class="card-title"><?=$this->lang->line('home')?$this->lang->line('home'):'Home'?> <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?=$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first')?$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first'):'If any changes have been made in above Frontend Customization section then save it first.'?>"></i></h4>
                    </div>
                    <div class="card-body">
                          <div class="row">
                            <div class="col-md-3">
                                <div class="card card-primary">
                                    <div class="card-body">
                                        <ul class="nav nav-pills flex-column" id="myTab4" role="tablist">
                                            <?php foreach($lang as $kay => $lan){ ?>
                                            <li class="nav-item">
                                                <a class="nav-link <?=$kay==0?'active':''?>" id="tab-<?=htmlspecialchars($lan['language'])?>" data-toggle="tab" href="#<?=htmlspecialchars($lan['language'])?>" role="tab" aria-controls="<?=htmlspecialchars($lan['language'])?>" aria-selected="true"><?=ucfirst(htmlspecialchars($lan['language']))?></a>
                                            </li>
                                            <?php } ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="card card-primary" id="home-card">
                                    <form action="<?=base_url('settings/save-home-setting')?>" method="POST" id="home-form">
                                        <div class="tab-content no-padding" id="myTab2Content">
                                            <?php foreach($lang as $kay => $lan){ ?>
                                              <div class="tab-pane fade <?=$kay==0?'show active':''?>" id="<?=htmlspecialchars($lan['language'])?>" role="tabpanel" aria-labelledby="tab-<?=htmlspecialchars($lan['language'])?>">
                                                <div class="card-header">
                                                  <h4><?=ucfirst(htmlspecialchars($lan['language']))?> 
                                                  <?php if($lan['language']=='english'){ ?>
                                                  <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?=$this->lang->line('must_enter_title_and_description_for_default_language')?$this->lang->line('must_enter_title_and_description_for_default_language'):'Must enter Title and Description for default language.'?>"></i>
                                                  <?php } ?>
                                                  </h4>
                                                </div>
                                                <div class="card-body row">
                                                    <div class="form-group col-md-12">
                                                        <label><?=$this->lang->line('title')?$this->lang->line('title'):'Title'?><span class="text-danger">*</span></label>
                                                        <input type="text" name="<?=htmlspecialchars($lan['language'])?>_title" value="<?=isset($home->{$lan['language']}->title)?htmlspecialchars($home->{$lan['language']}->title):''?>" class="form-control">
                                                    </div>
                                                    <div class="form-group col-md-12">
                                                        <label><?=$this->lang->line('description')?$this->lang->line('description'):'Description'?><span class="text-danger">*</span></label>
                                                        <textarea type="text" name="<?=$lan['language']?>_description" class="form-control"><?=isset($home->{$lan['language']}->description)?htmlspecialchars($home->{$lan['language']}->description):''?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php }  ?>
                                        </div>
                                        
                                        <div class="card-footer bg-whitesmoke text-md-right">
                                            <button class="btn btn-primary savebtn"><?=$this->lang->line('save_changes')?$this->lang->line('save_changes'):'Save Changes'?></button>
                                        </div>
                                        <div class="result"></div>
                                    </form>
                                </div>
                            </div>
                          </div>
                    </div>
                  </div>
                </div>


                <div class="col-md-12 <?=(isset($frontend_permissions->features) && !empty($frontend_permissions->features) && $frontend_permissions->features == 1)?'':'d-none'?>" id="feature_div">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h4 class="card-title"><?=$this->lang->line('features')?$this->lang->line('features'):'Features'?> <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?=$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first')?$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first'):'If any changes have been made in above Frontend Customization section then save it first.'?>"></i></h4>

                      <div class="card-header-action dropdown">
                        <a href="<?=base_url('front/create-feature')?>" class="btn btn-primary"><?=$this->lang->line('create')?$this->lang->line('create'):'Create'?></a>
                        
                      </div>
                    </div>
                    <div class="card-body">
                      <table class='table-striped' id='features_list'
                          data-toggle="table"
                          data-url="<?=base_url('front/get_feature')?>"
                          data-click-to-select="true"
                          data-side-pagination="server"
                          data-pagination="false"
                          data-page-list="[5, 10, 20, 50, 100, 200]"
                          data-search="false" data-show-columns="false"
                          data-show-refresh="false" data-trim-on-search="false"
                          data-sort-name="id" data-sort-order="asc"
                          data-mobile-responsive="true"
                          data-toolbar="" data-show-export="false"
                          data-maintain-selected="true"
                          data-export-types='["txt","excel"]'
                          data-export-options='{
                            "fileName": "features-list",
                            "ignoreColumn": ["state"] 
                          }'
                          data-query-params="queryParams">
                          <thead>
                            <tr>
                              <th data-field="title" data-sortable="true"><?=$this->lang->line('title')?$this->lang->line('title'):'Title'?></th>
                              <th data-field="description" data-sortable="true"><?=$this->lang->line('description')?$this->lang->line('description'):'Description'?></th>
                              <th data-field="action" data-sortable="false"><?=$this->lang->line('action')?$this->lang->line('action'):'Action'?></th>
                            </tr>
                          </thead>
                      </table>
                    </div>
                  </div>
                </div>


                
                <div class="col-md-12 <?=(isset($frontend_permissions->features) && !empty($frontend_permissions->features) && $frontend_permissions->features == 1)?'':'d-none'?>" id="pages_div">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h4 class="card-title"><?=$this->lang->line('pages')?$this->lang->line('pages'):'Pages'?> <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="" data-original-title="<?=$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first')?$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first'):'If any changes have been made in above Frontend Customization section then save it first.'?>"></i></h4>
                    </div>
                    <div class="card-body">
                      <table class='table-striped' id='pages_list'
                          data-toggle="table"
                          data-url="<?=base_url('front/get_pages')?>"
                          data-click-to-select="true"
                          data-side-pagination="server"
                          data-pagination="false"
                          data-page-list="[5, 10, 20, 50, 100, 200]"
                          data-search="false" data-show-columns="false"
                          data-show-refresh="false" data-trim-on-search="false"
                          data-sort-name="id" data-sort-order="asc"
                          data-mobile-responsive="true"
                          data-toolbar="" data-show-export="false"
                          data-maintain-selected="true"
                          data-export-types='["txt","excel"]'
                          data-export-options='{
                            "fileName": "pages-list",
                            "ignoreColumn": ["state"] 
                          }'
                          data-query-params="queryParams">
                          <thead>
                            <tr>
                              <th data-field="title" data-sortable="true"><?=$this->lang->line('pages_title')?$this->lang->line('pages_title'):'Page Title'?></th>
                              <th data-field="content" data-sortable="true"><?=$this->lang->line('pages_content')?$this->lang->line('pages_content'):'Page Content'?> (HTML)</th>
                              <th data-field="action" data-sortable="false"><?=$this->lang->line('action')?$this->lang->line('action'):'Action'?></th>
                            </tr>
                          </thead>
                      </table>
                    </div>
                  </div>
                </div>




              </div>
            </div>
          </section>
        </div>
      <?php $this->load->view('includes/footer'); ?>
    </div>
  </div>

  <form action="<?=base_url('front/edit-pages')?>" method="POST" class="modal-part" id="modal-edit-pages-part" data-title="<?=$this->lang->line('edit')?$this->lang->line('edit'):'Edit'?>" data-btn_update="<?=$this->lang->line('update')?$this->lang->line('update'):'Update'?>">
  <input type="hidden" name="update_id" id="update_id" value="">
  <div class="row">
    <div class="form-group col-md-12">
      <label><?=$this->lang->line('pages_content')?$this->lang->line('pages_content'):'Page Content'?> (HTML)<span class="text-danger">*</span></label>
      <textarea type="text" name="content" id="content" class="form-control"></textarea>
    </div>
  </div>
</form>
<div id="modal-edit-pages"></div>

<?php $this->load->view('includes/js'); ?>
</body>
</html>
