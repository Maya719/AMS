<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('includes/head'); ?>
</head>
<?php $this->load->view('pages/'.htmlspecialchars($page)); ?>
</html>
