<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('includes/head'); ?>
</head>
<body>
  <div id="app">
    <div class="main-wrapper">
      <?php $this->load->view('includes/navbar'); ?>
        <div class="main-content">
          <section class="section">
            <div class="section-header">
              <div class="section-header-back">
                <a href="<?=base_url('languages')?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
              </div>
              <h1><?=$this->lang->line('edit_language')?$this->lang->line('edit_language'):'Edit Language'?></h1>
              <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?=base_url()?>"><?=$this->lang->line('dashboard')?$this->lang->line('dashboard'):'Dashboard'?></a></div>
                <div class="breadcrumb-item active"><a href="<?=base_url('languages')?>"><?=$this->lang->line('languages')?$this->lang->line('languages'):'Languages'?></a></div>
                <div class="breadcrumb-item"><?=$this->lang->line('edit_language')?$this->lang->line('edit_language'):'Edit Language'?></div>
              </div>
            </div>

            <div class="section-body">
              <div class="row">


                <div class="col-md-3">
                    <div class="card card-primary">
                        <div class="card-body">
                            <ul class="nav nav-pills flex-column">
                                <?php foreach($languages as $kay => $lan){ ?>
                                <li class="nav-item">
                                    <a class="nav-link <?=$lan['language']==$this->uri->segment(3)?'active':''?>" href="<?=base_url('languages/editing/'.$lan['language'])?>"><?=ucfirst(htmlspecialchars($lan['language']))?></a>
                                </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>



                <div class="col-md-9">
                    <div class="card card-primary" id="language-card">
                        <form action="<?=base_url('languages/edit')?>" method="POST" id="language-form">
                            <div class="card-header">
                              <h4><?=$this->lang->line('editing')?$this->lang->line('editing'):'Editing'?> <?=ucfirst(htmlspecialchars($this->uri->segment(3)))?></h4>
                            </div>
                            <div class="card-body row">

                              <div class="form-group col-md-12">
                                  <label><?=ucfirst(htmlspecialchars($this->uri->segment(3)))?> <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('dont_edit_it_if_you_dont_want_to_edit_language_name')?$this->lang->line('dont_edit_it_if_you_dont_want_to_edit_language_name'):"Don't edit it if you don't want to edit language name."?>"></i></label>
                                  <input type="text" name="language" value="<?=ucfirst(htmlspecialchars($this->uri->segment(3)))?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Dashboard</label>
                                  <input type="text" name="dashboard" value="<?=$this->lang->line('dashboard')?$this->lang->line('dashboard'):'Dashboard'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Editing</label>
                                  <input type="text" name="editing" value="<?=$this->lang->line('editing')?$this->lang->line('editing'):'Editing'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Pages</label>
                                  <input type="text" name="pages" value="<?=$this->lang->line('pages')?$this->lang->line('pages'):'Pages'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Page Title</label>
                                  <input type="text" name="pages_title" value="<?=$this->lang->line('pages_title')?$this->lang->line('pages_title'):'Page Title'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Page Content</label>
                                  <input type="text" name="pages_content" value="<?=$this->lang->line('pages_content')?$this->lang->line('pages_content'):'Page Content'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Taxes</label>
                                  <input type="text" name="taxes" value="<?=$this->lang->line('taxes')?$this->lang->line('taxes'):'Taxes'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Tax Name</label>
                                  <input type="text" name="tax_name" value="<?=$this->lang->line('tax_name')?$this->lang->line('tax_name'):'Tax Name'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Tax Rate(%)</label>
                                  <input type="text" name="tax_rate" value="<?=$this->lang->line('tax_rate')?$this->lang->line('tax_rate'):'Tax Rate(%)'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Currency Symbol</label>
                                  <input type="text" name="currency_symbol" value="<?=$this->lang->line('currency_symbol')?$this->lang->line('currency_symbol'):'Currency Symbol'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Currency Code</label>
                                  <input type="text" name="currency_code" value="<?=$this->lang->line('currency_code')?$this->lang->line('currency_code'):'Currency Code'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit</label>
                                  <input type="text" name="edit" value="<?=$this->lang->line('edit')?$this->lang->line('edit'):'Edit'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Select Chat</label>
                                  <input type="text" name="select_chat" value="<?=$this->lang->line('select_chat')?$this->lang->line('select_chat'):'Select Chat'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>New Message</label>
                                  <input type="text" name="new_message" value="<?=$this->lang->line('new_message')?$this->lang->line('new_message'):'New Message'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Enable OR Disable Sections</label>
                                  <input type="text" name="enable_or_disable_sections" value="<?=$this->lang->line('enable_or_disable_sections')?$this->lang->line('enable_or_disable_sections'):'Enable OR Disable Sections'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Frontend Customization</label>
                                  <input type="text" name="frontend_customization" value="<?=$this->lang->line('frontend_customization')?$this->lang->line('frontend_customization'):'Frontend Customization'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Contact Form</label>
                                  <input type="text" name="contact_form" value="<?=$this->lang->line('contact_form')?$this->lang->line('contact_form'):'Contact Form'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Plans</label>
                                  <input type="text" name="subscription_plans" value="<?=$this->lang->line('subscription_plans')?$this->lang->line('subscription_plans'):'Plans'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Plan</label>
                                  <input type="text" name="plan" value="<?=$this->lang->line('plan')?$this->lang->line('plan'):'Plan'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>All</label>
                                  <input type="text" name="all" value="<?=$this->lang->line('all')?$this->lang->line('all'):'All'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Total</label>
                                  <input type="text" name="total" value="<?=$this->lang->line('total')?$this->lang->line('total'):'Total'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Subtotal</label>
                                  <input type="text" name="subtotal" value="<?=$this->lang->line('subtotal')?$this->lang->line('subtotal'):'Subtotal'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Item</label>
                                  <input type="text" name="item" value="<?=$this->lang->line('item')?$this->lang->line('item'):'Item'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Completed</label>
                                  <input type="text" name="completed" value="<?=$this->lang->line('completed')?$this->lang->line('completed'):'Completed'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Rejected</label>
                                  <input type="text" name="rejected" value="<?=$this->lang->line('rejected')?$this->lang->line('rejected'):'Rejected'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Pending</label>
                                  <input type="text" name="pending" value="<?=$this->lang->line('pending')?$this->lang->line('pending'):'Pending'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Accepted</label>
                                  <input type="text" name="accepted" value="<?=$this->lang->line('accepted')?$this->lang->line('accepted'):'Accepted'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Features</label>
                                  <input type="text" name="features" value="<?=$this->lang->line('features')?$this->lang->line('features'):'Features'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Contact</label>
                                  <input type="text" name="contact" value="<?=$this->lang->line('contact')?$this->lang->line('contact'):'Contact'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Get Start</label>
                                  <input type="text" name="get_start" value="<?=$this->lang->line('get_start')?$this->lang->line('get_start'):'Get Start'?>" class="form-control">
                              </div>
                              
                              <div class="form-group col-md-6">
                                  <label>Monthly</label>
                                  <input type="text" name="monthly" value="<?=$this->lang->line('monthly')?$this->lang->line('monthly'):'Monthly'?>" class="form-control">
                              </div>
                              
                              <div class="form-group col-md-6">
                                  <label>Yearly</label>
                                  <input type="text" name="yearly" value="<?=$this->lang->line('yearly')?$this->lang->line('yearly'):'Yearly'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Unlimited</label>
                                  <input type="text" name="unlimited" value="<?=$this->lang->line('unlimited')?$this->lang->line('unlimited'):'Unlimited'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Invoices</label>
                                  <input type="text" name="invoices" value="<?=$this->lang->line('invoices')?$this->lang->line('invoices'):'Invoices'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Invoice</label>
                                  <input type="text" name="invoice" value="<?=$this->lang->line('invoice')?$this->lang->line('invoice'):'Invoice'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Task Title</label>
                                  <input type="text" name="task_title" value="<?=$this->lang->line('task_title')?$this->lang->line('task_title'):'Task Title'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Projects</label>
                                  <input type="text" name="projects" value="<?=$this->lang->line('projects')?$this->lang->line('projects'):'Projects'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Project</label>
                                  <input type="text" name="project" value="<?=$this->lang->line('project')?$this->lang->line('project'):'Project'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Select Project</label>
                                  <input type="text" name="select_project" value="<?=$this->lang->line('select_project')?$this->lang->line('select_project'):'Select Project'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Details</label>
                                  <input type="text" name="details" value="<?=$this->lang->line('details')?$this->lang->line('details'):'Details'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Detail</label>
                                  <input type="text" name="detail" value="<?=$this->lang->line('detail')?$this->lang->line('detail'):'Detail'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Task Completed</label>
                                  <input type="text" name="task_completed" value="<?=$this->lang->line('task_completed')?$this->lang->line('task_completed'):'Task Completed'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Projects Detail</label>
                                  <input type="text" name="projects_detail" value="<?=$this->lang->line('projects_detail')?$this->lang->line('projects_detail'):'Projects Detail'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Latest</label>
                                  <input type="text" name="latest" value="<?=$this->lang->line('latest')?$this->lang->line('latest'):'Latest'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Old</label>
                                  <input type="text" name="old" value="<?=$this->lang->line('old')?$this->lang->line('old'):'Old'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create New Project</label>
                                  <input type="text" name="create_new_project" value="<?=$this->lang->line('create_new_project')?$this->lang->line('create_new_project'):'Create New Project'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Sort By</label>
                                  <input type="text" name="sort_by" value="<?=$this->lang->line('sort_by')?$this->lang->line('sort_by'):'Sort By'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Select Clients</label>
                                  <input type="text" name="select_clients" value="<?=$this->lang->line('select_clients')?$this->lang->line('select_clients'):'Select Clients'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Select Users</label>
                                  <input type="text" name="select_users" value="<?=$this->lang->line('select_users')?$this->lang->line('select_users'):'Select Users'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Select Status</label>
                                  <input type="text" name="select_status" value="<?=$this->lang->line('select_status')?$this->lang->line('select_status'):'Select Status'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Tasks</label>
                                  <input type="text" name="tasks" value="<?=$this->lang->line('tasks')?$this->lang->line('tasks'):'Tasks'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Task</label>
                                  <input type="text" name="task" value="<?=$this->lang->line('task')?$this->lang->line('task'):'Task'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Project Title</label>
                                  <input type="text" name="project_title" value="<?=$this->lang->line('project_title')?$this->lang->line('project_title'):'Project Title'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Trash</label>
                                  <input type="text" name="trash" value="<?=$this->lang->line('trash')?$this->lang->line('trash'):'Trash'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Low</label>
                                  <input type="text" name="low" value="<?=$this->lang->line('low')?$this->lang->line('low'):'Low'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Medium</label>
                                  <input type="text" name="medium" value="<?=$this->lang->line('medium')?$this->lang->line('medium'):'Medium'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>High</label>
                                  <input type="text" name="high" value="<?=$this->lang->line('high')?$this->lang->line('high'):'High'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Days</label>
                                  <input type="text" name="days" value="<?=$this->lang->line('days')?$this->lang->line('days'):'Days'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Left</label>
                                  <input type="text" name="left" value="<?=$this->lang->line('left')?$this->lang->line('left'):'Left'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Discount(%)</label>
                                  <input type="text" name="discount" value="<?=$this->lang->line('discount')?$this->lang->line('discount'):'Discount(%)'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Overdue</label>
                                  <input type="text" name="overdue" value="<?=$this->lang->line('overdue')?$this->lang->line('overdue'):'Overdue'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Due</label>
                                  <input type="text" name="due" value="<?=$this->lang->line('due')?$this->lang->line('due'):'Due'?>" class="form-control">
                              </div>
                              
                              <div class="form-group col-md-6">
                                  <label>User</label>
                                  <input type="text" name="user" value="<?=$this->lang->line('user')?$this->lang->line('user'):'User'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Task Detail</label>
                                  <input type="text" name="task_detail" value="<?=$this->lang->line('task_detail')?$this->lang->line('task_detail'):'Task Detail'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Name</label>
                                  <input type="text" name="name" value="<?=$this->lang->line('name')?$this->lang->line('name'):'Name'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Email</label>
                                  <input type="text" name="email" value="<?=$this->lang->line('email')?$this->lang->line('email'):'Email'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Upload Project Files</label>
                                  <input type="text" name="upload_project_files" value="<?=$this->lang->line('upload_project_files')?$this->lang->line('upload_project_files'):'Upload Project Files'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Project Files</label>
                                  <input type="text" name="project_files" value="<?=$this->lang->line('project_files')?$this->lang->line('project_files'):'Project Files'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Payment Gateway</label>
                                  <input type="text" name="payment_gateway" value="<?=$this->lang->line('payment_gateway')?$this->lang->line('payment_gateway'):'Payment Gateway'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Message</label>
                                  <input type="text" name="message" value="<?=$this->lang->line('message')?$this->lang->line('message'):'Message'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Type your message</label>
                                  <input type="text" name="type_your_message" value="<?=$this->lang->line('type_your_message')?$this->lang->line('type_your_message'):'Type your message'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Send Message</label>
                                  <input type="text" name="send_message" value="<?=$this->lang->line('send_message')?$this->lang->line('send_message'):'Send Message'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Login</label>
                                  <input type="text" name="login" value="<?=$this->lang->line('login')?$this->lang->line('login'):'Login'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Send</label>
                                  <input type="text" name="send" value="<?=$this->lang->line('send')?$this->lang->line('send'):'Send'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Profile</label>
                                  <input type="text" name="profile" value="<?=$this->lang->line('profile')?$this->lang->line('profile'):'Profile'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Password</label>
                                  <input type="text" name="password" value="<?=$this->lang->line('password')?$this->lang->line('password'):'Password'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Encryption</label>
                                  <input type="text" name="encryption" value="<?=$this->lang->line('encryption')?$this->lang->line('encryption'):'Encryption'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Team Members and Client can chat?</label>
                                  <input type="text" name="team_embers_and_client_can_chat" value="<?=$this->lang->line('team_embers_and_client_can_chat')?$this->lang->line('team_embers_and_client_can_chat'):'Team Members and Client can chat?'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>General permissions</label>
                                  <input type="text" name="general_permissions" value="<?=$this->lang->line('general_permissions')?$this->lang->line('general_permissions'):'General permissions'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Send test mail to</label>
                                  <input type="text" name="send_test_mail_to" value="<?=$this->lang->line('send_test_mail_to')?$this->lang->line('send_test_mail_to'):'Send test mail to'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Confirm Password</label>
                                  <input type="text" name="confirm_password" value="<?=$this->lang->line('confirm_password')?$this->lang->line('confirm_password'):'Confirm Password'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Forgot Password</label>
                                  <input type="text" name="forgot_password" value="<?=$this->lang->line('forgot_password')?$this->lang->line('forgot_password'):'Forgot Password'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Remember Me</label>
                                  <input type="text" name="remember_me" value="<?=$this->lang->line('remember_me')?$this->lang->line('remember_me'):'Remember Me'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Don't have an account?</label>
                                  <input type="text" name="dont_have_an_account" value="<?=$this->lang->line('dont_have_an_account')?$this->lang->line('dont_have_an_account'):"Don't have an account?"?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create One</label>
                                  <input type="text" name="create_one" value="<?=$this->lang->line('create_one')?$this->lang->line('create_one'):'Create One'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Register</label>
                                  <input type="text" name="register" value="<?=$this->lang->line('register')?$this->lang->line('register'):'Register'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>First Name</label>
                                  <input type="text" name="first_name" value="<?=$this->lang->line('first_name')?$this->lang->line('first_name'):'First Name'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Last Name</label>
                                  <input type="text" name="last_name" value="<?=$this->lang->line('last_name')?$this->lang->line('last_name'):'Last Name'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Password Confirmation</label>
                                  <input type="text" name="password_confirmation" value="<?=$this->lang->line('password_confirmation')?$this->lang->line('password_confirmation'):'Password Confirmation'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Already have an account?</label>
                                  <input type="text" name="already_have_an_account" value="<?=$this->lang->line('already_have_an_account')?$this->lang->line('already_have_an_account'):'Already have an account?'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Login Here</label>
                                  <input type="text" name="login_here" value="<?=$this->lang->line('login_here')?$this->lang->line('login_here'):'Login Here'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Notifications</label>
                                  <input type="text" name="notifications" value="<?=$this->lang->line('notifications')?$this->lang->line('notifications'):'Notifications'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>View</label>
                                  <input type="text" name="view" value="<?=$this->lang->line('view')?$this->lang->line('view'):'View'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>User Statistics</label>
                                  <input type="text" name="user_statistics" value="<?=$this->lang->line('user_statistics')?$this->lang->line('user_statistics'):'User Statistics'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Tasks Statistics</label>
                                  <input type="text" name="tasks_statistics" value="<?=$this->lang->line('tasks_statistics')?$this->lang->line('tasks_statistics'):'Tasks Statistics'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Project Statistics</label>
                                  <input type="text" name="project_statistics" value="<?=$this->lang->line('project_statistics')?$this->lang->line('project_statistics'):'Project Statistics'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>No new notifications</label>
                                  <input type="text" name="no_new_notifications" value="<?=$this->lang->line('no_new_notifications')?$this->lang->line('no_new_notifications'):'No new notifications.'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>View All</label>
                                  <input type="text" name="view_all" value="<?=$this->lang->line('view_all')?$this->lang->line('view_all'):'View All'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Clients</label>
                                  <input type="text" name="clients" value="<?=$this->lang->line('clients')?$this->lang->line('clients'):'Clients'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>ToDo</label>
                                  <input type="text" name="todo" value="<?=$this->lang->line('todo')?$this->lang->line('todo'):'ToDo'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit ToDo</label>
                                  <input type="text" name="edit_todo" value="<?=$this->lang->line('edit_todo')?$this->lang->line('edit_todo'):'Edit ToDo'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create New ToDo</label>
                                  <input type="text" name="create_new_dodo" value="<?=$this->lang->line('create_new_dodo')?$this->lang->line('create_new_dodo'):'Create New ToDo'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Notes</label>
                                  <input type="text" name="notes" value="<?=$this->lang->line('notes')?$this->lang->line('notes'):'Notes'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Note</label>
                                  <input type="text" name="note" value="<?=$this->lang->line('note')?$this->lang->line('note'):'Note'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create New Note</label>
                                  <input type="text" name="create_new_note" value="<?=$this->lang->line('create_new_note')?$this->lang->line('create_new_note'):'Create New Note'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit Note</label>
                                  <input type="text" name="edit_note" value="<?=$this->lang->line('edit_note')?$this->lang->line('edit_note'):'Edit Note'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Chat</label>
                                  <input type="text" name="chat" value="<?=$this->lang->line('chat')?$this->lang->line('chat'):'Chat'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Orders</label>
                                  <input type="text" name="orders" value="<?=$this->lang->line('orders')?$this->lang->line('orders'):'Orders'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>offline / bank transfer requests</label>
                                  <input type="text" name="offline_requests" value="<?=$this->lang->line('offline_requests')?$this->lang->line('offline_requests'):'offline / bank transfer requests'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Transactions</label>
                                  <input type="text" name="transactions" value="<?=$this->lang->line('transactions')?$this->lang->line('transactions'):'Transactions'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Transaction</label>
                                  <input type="text" name="transaction" value="<?=$this->lang->line('transaction')?$this->lang->line('transaction'):'Transaction'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Users and Plan</label>
                                  <input type="text" name="users_and_plan" value="<?=$this->lang->line('users_and_plan')?$this->lang->line('users_and_plan'):'Users and Plan'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Users and Plans</label>
                                  <input type="text" name="users_and_plans" value="<?=$this->lang->line('users_and_plans')?$this->lang->line('users_and_plans'):'Users and Plans'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>SaaS Admins</label>
                                  <input type="text" name="saas_admins" value="<?=$this->lang->line('saas_admins')?$this->lang->line('saas_admins'):'SaaS Admins'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Frontend</label>
                                  <input type="text" name="frontend" value="<?=$this->lang->line('frontend')?$this->lang->line('frontend'):'Frontend'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Settings</label>
                                  <input type="text" name="settings" value="<?=$this->lang->line('settings')?$this->lang->line('settings'):'Settings'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>General</label>
                                  <input type="text" name="general" value="<?=$this->lang->line('general')?$this->lang->line('general'):'General'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Print</label>
                                  <input type="text" name="print" value="<?=$this->lang->line('print')?$this->lang->line('print'):'Print'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Process Payment</label>
                                  <input type="text" name="process_payment" value="<?=$this->lang->line('process_payment')?$this->lang->line('process_payment'):'Process Payment'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Payment Type</label>
                                  <input type="text" name="payment_type" value="<?=$this->lang->line('payment_type')?$this->lang->line('payment_type'):'Payment Type'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Payment Date</label>
                                  <input type="text" name="payment_date" value="<?=$this->lang->line('payment_date')?$this->lang->line('payment_date'):'Payment Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Payment</label>
                                  <input type="text" name="payment" value="<?=$this->lang->line('payment')?$this->lang->line('payment'):'Payment'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Payments</label>
                                  <input type="text" name="payments" value="<?=$this->lang->line('payments')?$this->lang->line('payments'):'Payments'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Payment Status</label>
                                  <input type="text" name="payment_status" value="<?=$this->lang->line('payment_status')?$this->lang->line('payment_status'):'Payment Status'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Languages</label>
                                  <input type="text" name="languages" value="<?=$this->lang->line('languages')?$this->lang->line('languages'):'Languages'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit Language</label>
                                  <input type="text" name="edit_language" value="<?=$this->lang->line('edit_language')?$this->lang->line('edit_language'):'Edit Language'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Update</label>
                                  <input type="text" name="update" value="<?=$this->lang->line('update')?$this->lang->line('update'):'Update'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit Project</label>
                                  <input type="text" name="edit_project" value="<?=$this->lang->line('edit_project')?$this->lang->line('edit_project'):'Edit Project'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Delete</label>
                                  <input type="text" name="delete" value="<?=$this->lang->line('delete')?$this->lang->line('delete'):'Delete'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Budget</label>
                                  <input type="text" name="budget" value="<?=$this->lang->line('budget')?$this->lang->line('budget'):'Budget'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Show project budget</label>
                                  <input type="text" name="show_project_budget" value="<?=$this->lang->line('show_project_budget')?$this->lang->line('show_project_budget'):'Show project budget'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Can change task status</label>
                                  <input type="text" name="can_change_task_status" value="<?=$this->lang->line('can_change_task_status')?$this->lang->line('can_change_task_status'):'Can change task status'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Client Detail</label>
                                  <input type="text" name="client_detail" value="<?=$this->lang->line('client_detail')?$this->lang->line('client_detail'):'Client Detail'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>View Tasks</label>
                                  <input type="text" name="view_tasks" value="<?=$this->lang->line('view_tasks')?$this->lang->line('view_tasks'):'View Tasks'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Search</label>
                                  <input type="text" name="search" value="<?=$this->lang->line('search')?$this->lang->line('search'):'Search'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Google Analytics</label>
                                  <input type="text" name="google_analytics" value="<?=$this->lang->line('google_analytics')?$this->lang->line('google_analytics'):'Google Analytics'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Footer Text</label>
                                  <input type="text" name="footer_text" value="<?=$this->lang->line('footer_text')?$this->lang->line('footer_text'):'Footer Text'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Company Name</label>
                                  <input type="text" name="company_name" value="<?=$this->lang->line('company_name')?$this->lang->line('company_name'):'Company Name'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Company</label>
                                  <input type="text" name="company" value="<?=$this->lang->line('company')?$this->lang->line('company'):'Company'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>User Permissions</label>
                                  <input type="text" name="user_permissions" value="<?=$this->lang->line('user_permissions')?$this->lang->line('user_permissions'):'User Permissions'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Client Permissions</label>
                                  <input type="text" name="client_permissions" value="<?=$this->lang->line('client_permissions')?$this->lang->line('client_permissions'):'Client Permissions'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Earnings</label>
                                  <input type="text" name="earnings" value="<?=$this->lang->line('earnings')?$this->lang->line('earnings'):'Earnings'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Last days earning</label>
                                  <input type="text" name="last_days_earning" value="<?=$this->lang->line('last_days_earning')?$this->lang->line('last_days_earning'):'Last 30 days earning'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Users Statistics</label>
                                  <input type="text" name="users_statistics" value="<?=$this->lang->line('users_statistics')?$this->lang->line('users_statistics'):'Users Statistics'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Active</label>
                                  <input type="text" name="active" value="<?=$this->lang->line('active')?$this->lang->line('active'):'Active'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Deactive</label>
                                  <input type="text" name="deactive" value="<?=$this->lang->line('deactive')?$this->lang->line('deactive'):'Deactive'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>In Review</label>
                                  <input type="text" name="in_review" value="<?=$this->lang->line('in_review')?$this->lang->line('in_review'):'In Review'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>In Progress</label>
                                  <input type="text" name="in_progress" value="<?=$this->lang->line('in_progress')?$this->lang->line('in_progress'):'In Progress'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Finished</label>
                                  <input type="text" name="finished" value="<?=$this->lang->line('finished')?$this->lang->line('finished'):'Finished'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Today</label>
                                  <input type="text" name="today" value="<?=$this->lang->line('today')?$this->lang->line('today'):'Today'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Upcoming</label>
                                  <input type="text" name="upcoming" value="<?=$this->lang->line('upcoming')?$this->lang->line('upcoming'):'Upcoming'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>On Going</label>
                                  <input type="text" name="on_going" value="<?=$this->lang->line('on_going')?$this->lang->line('on_going'):'On Going'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Not Started</label>
                                  <input type="text" name="not_started" value="<?=$this->lang->line('not_started')?$this->lang->line('not_started'):'Not Started'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Task Status</label>
                                  <input type="text" name="task_status" value="<?=$this->lang->line('task_status')?$this->lang->line('task_status'):'Task Status'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Project Status</label>
                                  <input type="text" name="project_status" value="<?=$this->lang->line('project_status')?$this->lang->line('project_status'):'Project Status'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit User</label>
                                  <input type="text" name="edit_user" value="<?=$this->lang->line('edit_user')?$this->lang->line('edit_user'):'Edit User'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>User Profile</label>
                                  <input type="text" name="user_profile" value="<?=$this->lang->line('user_profile')?$this->lang->line('user_profile'):'User Profile'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Free</label>
                                  <input type="text" name="free" value="<?=$this->lang->line('free')?$this->lang->line('free'):'Free'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Paid</label>
                                  <input type="text" name="paid" value="<?=$this->lang->line('paid')?$this->lang->line('paid'):'Paid'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Expired</label>
                                  <input type="text" name="expired" value="<?=$this->lang->line('expired')?$this->lang->line('expired'):'Expired'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Logout</label>
                                  <input type="text" name="logout" value="<?=$this->lang->line('logout')?$this->lang->line('logout'):'Logout'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create</label>
                                  <input type="text" name="create" value="<?=$this->lang->line('create')?$this->lang->line('create'):'Create'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Language name</label>
                                  <input type="text" name="language_name" value="<?=$this->lang->line('language_name')?$this->lang->line('language_name'):'Language name'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create New User</label>
                                  <input type="text" name="create_new_user" value="<?=$this->lang->line('create_new_user')?$this->lang->line('create_new_user'):'Create New User'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Title</label>
                                  <input type="text" name="title" value="<?=$this->lang->line('title')?$this->lang->line('title'):'Title'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Description</label>
                                  <input type="text" name="description" value="<?=$this->lang->line('description')?$this->lang->line('description'):'Description'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Priority</label>
                                  <input type="text" name="priority" value="<?=$this->lang->line('priority')?$this->lang->line('priority'):'Priority'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Comments</label>
                                  <input type="text" name="comments" value="<?=$this->lang->line('comments')?$this->lang->line('comments'):'Comments'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Attachments</label>
                                  <input type="text" name="attachments" value="<?=$this->lang->line('attachments')?$this->lang->line('attachments'):'Attachments'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Invoice Date</label>
                                  <input type="text" name="invoice_date" value="<?=$this->lang->line('invoice_date')?$this->lang->line('invoice_date'):'Invoice Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Due Date</label>
                                  <input type="text" name="due_date" value="<?=$this->lang->line('due_date')?$this->lang->line('due_date'):'Due Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Pending Tasks</label>
                                  <input type="text" name="pending_tasks" value="<?=$this->lang->line('pending_tasks')?$this->lang->line('pending_tasks'):'Pending Tasks'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Completed Tasks</label>
                                  <input type="text" name="completed_tasks" value="<?=$this->lang->line('completed_tasks')?$this->lang->line('completed_tasks'):'Completed Tasks'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Total Tasks</label>
                                  <input type="text" name="total_tasks" value="<?=$this->lang->line('total_tasks')?$this->lang->line('total_tasks'):'Total Tasks'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Ending Date</label>
                                  <input type="text" name="ending_date" value="<?=$this->lang->line('ending_date')?$this->lang->line('ending_date'):'Ending Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Starting Date</label>
                                  <input type="text" name="starting_date" value="<?=$this->lang->line('starting_date')?$this->lang->line('starting_date'):'Starting Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create Feature</label>
                                  <input type="text" name="create_feature" value="<?=$this->lang->line('create_feature')?$this->lang->line('create_feature'):'Create Feature'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Price</label>
                                  <input type="text" name="price_usd" value="<?=$this->lang->line('price_usd')?$this->lang->line('price_usd'):'Price'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Amount</label>
                                  <input type="text" name="amount_usd" value="<?=$this->lang->line('amount_usd')?$this->lang->line('amount_usd'):'Amount'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Billed To</label>
                                  <input type="text" name="billed_to" value="<?=$this->lang->line('billed_to')?$this->lang->line('billed_to'):'Billed To'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Billing Type</label>
                                  <input type="text" name="billing_type" value="<?=$this->lang->line('billing_type')?$this->lang->line('billing_type'):'Billing Type'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Date</label>
                                  <input type="text" name="date" value="<?=$this->lang->line('date')?$this->lang->line('date'):'Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Home</label>
                                  <input type="text" name="home" value="<?=$this->lang->line('home')?$this->lang->line('home'):'Home'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Expiring</label>
                                  <input type="text" name="expiring" value="<?=$this->lang->line('expiring')?$this->lang->line('expiring'):'Expiring'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Status</label>
                                  <input type="text" name="status" value="<?=$this->lang->line('status')?$this->lang->line('status'):'Status'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Assign Users</label>
                                  <input type="text" name="assign_users" value="<?=$this->lang->line('assign_users')?$this->lang->line('assign_users'):'Assign Users'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Project Users</label>
                                  <input type="text" name="project_users" value="<?=$this->lang->line('project_users')?$this->lang->line('project_users'):'Project Users'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Action</label>
                                  <input type="text" name="action" value="<?=$this->lang->line('action')?$this->lang->line('action'):'Action'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Role</label>
                                  <input type="text" name="role" value="<?=$this->lang->line('role')?$this->lang->line('role'):'Role'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Phone</label>
                                  <input type="text" name="phone" value="<?=$this->lang->line('phone')?$this->lang->line('phone'):'Phone'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Project Client</label>
                                  <input type="text" name="project_client" value="<?=$this->lang->line('project_client')?$this->lang->line('project_client'):'Project Client'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Features and Usage</label>
                                  <input type="text" name="features_and_usage" value="<?=$this->lang->line('features_and_usage')?$this->lang->line('features_and_usage'):'Features and Usage'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Request Date</label>
                                  <input type="text" name="request_date" value="<?=$this->lang->line('request_date')?$this->lang->line('request_date'):'Request Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Alert...</label>
                                  <input type="text" name="alert" value="<?=$this->lang->line('alert')?$this->lang->line('alert'):'Alert...'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Renew it now.</label>
                                  <input type="text" name="renew_it_now" value="<?=$this->lang->line('renew_it_now')?$this->lang->line('renew_it_now'):'Renew it now.'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Renew Plan.</label>
                                  <input type="text" name="renew_plan" value="<?=$this->lang->line('renew_plan')?$this->lang->line('renew_plan'):'Renew Plan.'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Upgrade</label>
                                  <input type="text" name="subscribe" value="<?=$this->lang->line('subscribe')?$this->lang->line('subscribe'):'Upgrade'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Task Overview</label>
                                  <input type="text" name="task_overview" value="<?=$this->lang->line('task_overview')?$this->lang->line('task_overview'):'Task Overview'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Plan Expiry Date</label>
                                  <input type="text" name="plan_expiry_date" value="<?=$this->lang->line('plan_expiry_date')?$this->lang->line('plan_expiry_date'):'Plan Expiry Date'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>User Plan</label>
                                  <input type="text" name="user_plan" value="<?=$this->lang->line('user_plan')?$this->lang->line('user_plan'):'User Plan'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Mobile</label>
                                  <input type="text" name="mobile" value="<?=$this->lang->line('mobile')?$this->lang->line('mobile'):'Mobile'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Razorpay</label>
                                  <input type="text" name="razorpay" value="<?=$this->lang->line('razorpay')?$this->lang->line('razorpay'):'Razorpay'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Key ID</label>
                                  <input type="text" name="key_id" value="<?=$this->lang->line('key_id')?$this->lang->line('key_id'):'Key ID'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Stripe</label>
                                  <input type="text" name="stripe" value="<?=$this->lang->line('stripe')?$this->lang->line('stripe'):'Stripe'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Secret Key</label>
                                  <input type="text" name="secret_key" value="<?=$this->lang->line('secret_key')?$this->lang->line('secret_key'):'Secret Key'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Publishable Key</label>
                                  <input type="text" name="publishable_key" value="<?=$this->lang->line('publishable_key')?$this->lang->line('publishable_key'):'Publishable Key'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Paypal</label>
                                  <input type="text" name="paypal" value="<?=$this->lang->line('paypal')?$this->lang->line('paypal'):'Paypal'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Paypal Client ID</label>
                                  <input type="text" name="paypal_client_id" value="<?=$this->lang->line('paypal_client_id')?$this->lang->line('paypal_client_id'):'Paypal Client ID'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Timezone</label>
                                  <input type="text" name="timezone" value="<?=$this->lang->line('timezone')?$this->lang->line('timezone'):'Timezone'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Username/Email</label>
                                  <input type="text" name="username_email" value="<?=$this->lang->line('username_email')?$this->lang->line('username_email'):'Username/Email'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>SMTP Port</label>
                                  <input type="text" name="smtp_port" value="<?=$this->lang->line('smtp_port')?$this->lang->line('smtp_port'):'SMTP Port'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>SMTP Host</label>
                                  <input type="text" name="smtp_host" value="<?=$this->lang->line('smtp_host')?$this->lang->line('smtp_host'):'SMTP Host'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Favicon</label>
                                  <input type="text" name="favicon" value="<?=$this->lang->line('favicon')?$this->lang->line('favicon'):'Favicon'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>File</label>
                                  <input type="text" name="file" value="<?=$this->lang->line('file')?$this->lang->line('file'):'File'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Size</label>
                                  <input type="text" name="size" value="<?=$this->lang->line('size')?$this->lang->line('size'):'Size'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit Task</label>
                                  <input type="text" name="edit_task" value="<?=$this->lang->line('edit_task')?$this->lang->line('edit_task'):'Edit Task'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Create New Task</label>
                                  <input type="text" name="create_new_task" value="<?=$this->lang->line('create_new_task')?$this->lang->line('create_new_task'):'Create New Task'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>File Type</label>
                                  <input type="text" name="file_type" value="<?=$this->lang->line('file_type')?$this->lang->line('file_type'):'File Type'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Half Logo</label>
                                  <input type="text" name="half_logo" value="<?=$this->lang->line('half_logo')?$this->lang->line('half_logo'):'Half Logo'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Full Logo</label>
                                  <input type="text" name="full_logo" value="<?=$this->lang->line('full_logo')?$this->lang->line('full_logo'):'Full Logo'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>File Upload Format</label>
                                  <input type="text" name="file_upload_format" value="<?=$this->lang->line('file_upload_format')?$this->lang->line('file_upload_format'):'File Upload Format'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Time Format</label>
                                  <input type="text" name="time_format" value="<?=$this->lang->line('time_format')?$this->lang->line('time_format'):'Time Format'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Date Format</label>
                                  <input type="text" name="date_format" value="<?=$this->lang->line('date_format')?$this->lang->line('date_format'):'Date Format'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Edit Feature</label>
                                  <input type="text" name="edit_feature" value="<?=$this->lang->line('edit_feature')?$this->lang->line('edit_feature'):'Edit Feature'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Save Changes</label>
                                  <input type="text" name="save_changes" value="<?=$this->lang->line('save_changes')?$this->lang->line('save_changes'):'Save Changes'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Landing Page</label>
                                  <input type="text" name="landing_page" value="<?=$this->lang->line('landing_page')?$this->lang->line('landing_page'):'Landing Page'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Offline / Bank Transfer</label>
                                  <input type="text" name="offline_bank_transfer" value="<?=$this->lang->line('offline_bank_transfer')?$this->lang->line('offline_bank_transfer'):'Offline / Bank Transfer'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>No Number</label>
                                  <input type="text" name="no_number" value="<?=$this->lang->line('no_number')?$this->lang->line('no_number'):'No Number'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Current System Version:</label>
                                  <input type="text" name="current_system_version" value="<?=$this->lang->line('current_system_version')?$this->lang->line('current_system_version'):'Current System Version:'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Update Guide</label>
                                  <input type="text" name="update_guide" value="<?=$this->lang->line('update_guide')?$this->lang->line('update_guide'):'Update Guide'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Install Update</label>
                                  <input type="text" name="install_update" value="<?=$this->lang->line('install_update')?$this->lang->line('install_update'):'Install Update'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Choose file</label>
                                  <input type="text" name="choose_file" value="<?=$this->lang->line('choose_file')?$this->lang->line('choose_file'):'Choose file'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Select Task</label>
                                  <input type="text" name="select_task" value="<?=$this->lang->line('select_task')?$this->lang->line('select_task'):'Select Task'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Gantt</label>
                                  <input type="text" name="gantt" value="<?=$this->lang->line('gantt')?$this->lang->line('gantt'):'Gantt'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Leaves</label>
                                  <input type="text" name="leaves" value="<?=$this->lang->line('leaves')?$this->lang->line('leaves'):'Leaves'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Team Members</label>
                                  <input type="text" name="users" value="<?=$this->lang->line('team_members')?$this->lang->line('team_members'):'Team Members'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Users</label>
                                  <input type="text" name="users" value="<?=$this->lang->line('users')?$this->lang->line('users'):'Users'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Receipt</label>
                                  <input type="text" name="receipt" value="<?=$this->lang->line('receipt')?$this->lang->line('receipt'):'Receipt'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Timesheet</label>
                                  <input type="text" name="timesheet" value="<?=$this->lang->line('timesheet')?$this->lang->line('timesheet'):'Timesheet'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Calendar</label>
                                  <input type="text" name="calendar" value="<?=$this->lang->line('calendar')?$this->lang->line('calendar'):'Calendar'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Start Timer</label>
                                  <input type="text" name="start_timer" value="<?=$this->lang->line('start_timer')?$this->lang->line('start_timer'):'Start Timer'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Stop Timer</label>
                                  <input type="text" name="stop_timer" value="<?=$this->lang->line('stop_timer')?$this->lang->line('stop_timer'):'Stop Timer'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Starting Time</label>
                                  <input type="text" name="starting_time" value="<?=$this->lang->line('starting_time')?$this->lang->line('starting_time'):'Starting Time'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Ending Time</label>
                                  <input type="text" name="ending_time" value="<?=$this->lang->line('ending_time')?$this->lang->line('ending_time'):'Ending Time'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Total Time</label>
                                  <input type="text" name="total_time" value="<?=$this->lang->line('total_time')?$this->lang->line('total_time'):'Total Time'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Leave Reason</label>
                                  <input type="text" name="leave_reason" value="<?=$this->lang->line('leave_reason')?$this->lang->line('leave_reason'):'Leave Reason'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Leave Days</label>
                                  <input type="text" name="leave_days" value="<?=$this->lang->line('leave_days')?$this->lang->line('leave_days'):'Leave Days'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Finance</label>
                                  <input type="text" name="finance" value="<?=$this->lang->line('finance')?$this->lang->line('finance'):'Finance'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Expenses</label>
                                  <input type="text" name="expenses" value="<?=$this->lang->line('expenses')?$this->lang->line('expenses'):'Expenses'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>About Us</label>
                                  <input type="text" name="about" value="<?=$this->lang->line('about')?$this->lang->line('about'):'About Us'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Terms and Conditions</label>
                                  <input type="text" name="terms_and_conditions" value="<?=$this->lang->line('terms_and_conditions')?$this->lang->line('terms_and_conditions'):'Terms and Conditions'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Privacy Policy</label>
                                  <input type="text" name="privacy_policy" value="<?=$this->lang->line('privacy_policy')?$this->lang->line('privacy_policy'):'Privacy Policy'?>" class="form-control">
                              </div>
                              
                              <div class="form-group col-md-6">
                                  <label>Icon</label>
                                  <input type="text" name="icon" value="<?=$this->lang->line('icon')?$this->lang->line('icon'):'Icon'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Modules</label>
                                  <input type="text" name="modules" value="<?=$this->lang->line('modules')?$this->lang->line('modules'):'Modules'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Custom Currency</label>
                                  <input type="text" name="custom_currency" value="<?=$this->lang->line('custom_currency')?$this->lang->line('custom_currency'):'Custom Currency'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Storage</label>
                                  <input type="text" name="storage" value="<?=$this->lang->line('storage')?$this->lang->line('storage'):'Storage'?>" class="form-control">
                              </div>
                              <div class="form-group col-md-6">
                                  <label>Select All</label>
                                  <input type="text" name="select_all" value="<?=$this->lang->line('select_all')?$this->lang->line('select_all'):'Select All'?>" class="form-control">
                              </div>
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              

                              

                              
                              
                              
                              

                              
                              
                              <div class="form-group col-md-12">
                                  <label>This email will not be updated latter.</label>
                                  <input type="text" name="this_email_will_not_be_updated_latter" value="<?=$this->lang->line('this_email_will_not_be_updated_latter')?$this->lang->line('this_email_will_not_be_updated_latter'):'This email will not be updated latter.'?>" class="form-control">
                              </div>
                                <div class="form-group col-md-12">
                                    <label>We will send a link to reset your password.</label>
                                    <input type="text" name="we_will_send_a_link_to_reset_your_password" value="<?=$this->lang->line('we_will_send_a_link_to_reset_your_password')?$this->lang->line('we_will_send_a_link_to_reset_your_password'):'We will send a link to reset your password.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Including Admins, Clients and Users.</label>
                                    <input type="text" name="including_admins_clients_and_users" value="<?=$this->lang->line('including_admins_clients_and_users')?$this->lang->line('including_admins_clients_and_users'):'Including Admins, Clients and Users.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Your subscription plan has been expired on date</label>
                                    <input type="text" name="your_subscription_plan_has_been_expired_on_date" value="<?=$this->lang->line('your_subscription_plan_has_been_expired_on_date')?$this->lang->line('your_subscription_plan_has_been_expired_on_date'):'Your subscription plan has been expired on date'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Your current subscription plan is expiring on date</label>
                                    <input type="text" name="your_current_subscription_plan_is_expiring_on_date" value="<?=$this->lang->line('your_current_subscription_plan_is_expiring_on_date')?$this->lang->line('your_current_subscription_plan_is_expiring_on_date'):'Your current subscription plan is expiring on date'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>This is your current active plan and expiring on date</label>
                                    <input type="text" name="this_is_your_current_active_plan_and_expiring_on_date" value="<?=$this->lang->line('this_is_your_current_active_plan_and_expiring_on_date')?$this->lang->line('this_is_your_current_active_plan_and_expiring_on_date'):'This is your current active plan and expiring on date'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Set value in minus (-1) to make it Unlimited.</label>
                                    <input type="text" name="set_value_in_minus_to_make_it_unlimited" value="<?=$this->lang->line('set_value_in_minus_to_make_it_unlimited')?$this->lang->line('set_value_in_minus_to_make_it_unlimited'):'Set value in minus (-1) to make it Unlimited.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Leave Password and Confirm Password empty for no change in Password.</label>
                                    <input type="text" name="leave_password_and_confirm_password_empty_for_no_change_in_password" value="<?=$this->lang->line('leave_password_and_confirm_password_empty_for_no_change_in_password')?$this->lang->line('leave_password_and_confirm_password_empty_for_no_change_in_password'):'Leave Password and Confirm Password empty for no change in Password.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Disable "Landing Page" option to Disable whole frontend.</label>
                                    <input type="text" name="disable_landing_page_option_to_disable_whole_frontend" value="<?=$this->lang->line('disable_landing_page_option_to_disable_whole_frontend')?$this->lang->line('disable_landing_page_option_to_disable_whole_frontend'):'Disable Landing Page option to Disable whole frontend.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>If any changes have been made in above "Frontend Customization" section then save it first.</label>
                                    <input type="text" name="if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first" value="<?=$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first')?$this->lang->line('if_any_changes_have_been_made_in_above_frontend_customization_section_then_save_it_first'):'If any changes have been made in above Frontend Customization section then save it first.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Must enter Title and Description for default language.</label>
                                    <input type="text" name="must_enter_title_and_description_for_default_language" value="<?=$this->lang->line('must_enter_title_and_description_for_default_language')?$this->lang->line('must_enter_title_and_description_for_default_language'):'Must enter Title and Description for default language.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Show Subscription Plan Expiry Alert Before</label>
                                    <input type="text" name="show_subscription_plan_expiry_alert_before" value="<?=$this->lang->line('show_subscription_plan_expiry_alert_before')?$this->lang->line('show_subscription_plan_expiry_alert_before'):'Show Subscription Plan Expiry Alert Before'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>This will show alert box in main dashboard to the user about their plan expiry date.</label>
                                    <input type="text" name="this_will_show_alert_box_in_main_dashboard_to_the_user_about_their_plan_expiry_date" value="<?=$this->lang->line('this_will_show_alert_box_in_main_dashboard_to_the_user_about_their_plan_expiry_date')?$this->lang->line('this_will_show_alert_box_in_main_dashboard_to_the_user_about_their_plan_expiry_date'):'This will show alert box in main dashboard to the user about their plan expiry date.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Only this type of files going to be allowed to upload in projects and tasks.</label>
                                    <input type="text" name="only_this_type_of_files_going_to_be_allowed_to_upload_in_projects_and_tasks" value="<?=$this->lang->line('only_this_type_of_files_going_to_be_allowed_to_upload_in_projects_and_tasks')?$this->lang->line('only_this_type_of_files_going_to_be_allowed_to_upload_in_projects_and_tasks'):'Only this type of files going to be allowed to upload in projects and tasks.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You have to contact a user by yourself for further process.</label>
                                    <input type="text" name="you_have_to_contact_a_user_by_yourself_for_further_process" value="<?=$this->lang->line('you_have_to_contact_a_user_by_yourself_for_further_process')?$this->lang->line('you_have_to_contact_a_user_by_yourself_for_further_process'):'You have to contact a user by yourself for further process.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Select the update zip file and hit Install Update button.</label>
                                    <input type="text" name="select_the_update_zip_file_and_hit_install_update_button" value="<?=$this->lang->line('select_the_update_zip_file_and_hit_install_update_button')?$this->lang->line('select_the_update_zip_file_and_hit_install_update_button'):'Select the update zip file and hit Install Update button.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Please take a backup before going further. Follow the further instructions given with the update file.</label>
                                    <input type="text" name="please_take_a_backup_before_going_further_follow_the_further_instructions_given_with_the_update_file" value="<?=$this->lang->line('please_take_a_backup_before_going_further_follow_the_further_instructions_given_with_the_update_file')?$this->lang->line('please_take_a_backup_before_going_further_follow_the_further_instructions_given_with_the_update_file'):'Please take a backup before going further. Follow the further instructions given with the update file.'?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Don't edit it if you don't want to edit language name.</label>
                                    <input type="text" name="dont_edit_it_if_you_dont_want_to_edit_language_name" value="<?=$this->lang->line('dont_edit_it_if_you_dont_want_to_edit_language_name')?$this->lang->line('dont_edit_it_if_you_dont_want_to_edit_language_name'):"Don't edit it if you don't want to edit language name."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Leave empty for no changes.</label>
                                    <input type="text" name="leave_empty_for_no_changes" value="<?=$this->lang->line('leave_empty_for_no_changes')?$this->lang->line('leave_empty_for_no_changes'):"Leave empty for no changes."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Add users who will work on this project. Only this users are able to see this project.</label>
                                    <input type="text" name="add_users_who_will_work_on_this_project_only_this_users_are_able_to_see_this_project" value="<?=$this->lang->line('add_users_who_will_work_on_this_project_only_this_users_are_able_to_see_this_project')?$this->lang->line('add_users_who_will_work_on_this_project_only_this_users_are_able_to_see_this_project'):"Add users who will work on this project. Only this users are able to see this project."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Assign task to the users who will work on this task. Only this users are able to see this task.</label>
                                    <input type="text" name="assign_task_to_the_users_who_will_work_on_this_task_only_this_users_are_able_to_se_this_task" value="<?=$this->lang->line('assign_task_to_the_users_who_will_work_on_this_task_only_this_users_are_able_to_se_this_task')?$this->lang->line('assign_task_to_the_users_who_will_work_on_this_task_only_this_users_are_able_to_se_this_task'):"Assign task to the users who will work on this task. Only this users are able to see this task."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Admin always have all the permission. Here you can set permissions for users and clients.</label>
                                    <input type="text" name="admin_always_have_all_the_permission_here_you_can_set_permissions_for_users_and_clients" value="<?=$this->lang->line('admin_always_have_all_the_permission_here_you_can_set_permissions_for_users_and_clients')?$this->lang->line('admin_always_have_all_the_permission_here_you_can_set_permissions_for_users_and_clients'):"Admin always have all the permission. Here you can set permissions for users and clients."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Only admin have permission to add, edit and delete users. You can make any user as admin they will get all this permissions by default.</label>
                                    <input type="text" name="only_admin_have_permission_to_add_edit_and_delete_users_you_can_make_any_user_as_admin_they_will_get_all_this_permissions_by_default" value="<?=$this->lang->line('only_admin_have_permission_to_add_edit_and_delete_users_you_can_make_any_user_as_admin_they_will_get_all_this_permissions_by_default')?$this->lang->line('only_admin_have_permission_to_add_edit_and_delete_users_you_can_make_any_user_as_admin_they_will_get_all_this_permissions_by_default'):"Only admin have permission to add, edit and delete users. You can make any user as admin they will get all this permissions by default."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Settings have some some sensetive information about application. Make sure you have proper knowledge about what permission you are giving to the users.</label>
                                    <input type="text" name="settings_have_some_some_sensetive_information_about_application_make_sure_you_have_proper_knowledge_about_what_permission_you_are_giving_to_the_users" value="<?=$this->lang->line('settings_have_some_some_sensetive_information_about_application_make_sure_you_have_proper_knowledge_about_what_permission_you_are_giving_to_the_users')?$this->lang->line('settings_have_some_some_sensetive_information_about_application_make_sure_you_have_proper_knowledge_about_what_permission_you_are_giving_to_the_users'):"Settings have some some sensetive information about application. Make sure you have proper knowledge about what permission you are giving to the users."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>New user registered.</label>
                                    <input type="text" name="new_user_registered" value="<?=$this->lang->line('new_user_registered')?$this->lang->line('new_user_registered'):"New user registered."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Ordered subscription plan</label>
                                    <input type="text" name="ordered_subscription_plan" value="<?=$this->lang->line('ordered_subscription_plan')?$this->lang->line('ordered_subscription_plan'):"Ordered subscription plan"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Your Offline / Bank Transfer request accepted for subscription plan</label>
                                    <input type="text" name="your_offline_bank_transfer_request_accepted_for_subscription_plan" value="<?=$this->lang->line('your_offline_bank_transfer_request_accepted_for_subscription_plan')?$this->lang->line('your_offline_bank_transfer_request_accepted_for_subscription_plan'):"Your Offline / Bank Transfer request accepted for subscription plan"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Offline / Bank Transfer request created for subscription plan</label>
                                    <input type="text" name="offline_bank_transfer_request_created_for_subscription_plan" value="<?=$this->lang->line('offline_bank_transfer_request_created_for_subscription_plan')?$this->lang->line('offline_bank_transfer_request_created_for_subscription_plan'):"Offline / Bank Transfer request created for subscription plan"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>task file uploaded.</label>
                                    <input type="text" name="task_file_uploaded" value="<?=$this->lang->line('task_file_uploaded')?$this->lang->line('task_file_uploaded'):"task file uploaded."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>New task comment</label>
                                    <input type="text" name="new_task_comment" value="<?=$this->lang->line('new_task_comment')?$this->lang->line('new_task_comment'):"New task comment"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Task status changed.</label>
                                    <input type="text" name="task_status_changed" value="<?=$this->lang->line('task_status_changed')?$this->lang->line('task_status_changed'):"Task status changed."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>project file uploaded.</label>
                                    <input type="text" name="project_file_uploaded" value="<?=$this->lang->line('project_file_uploaded')?$this->lang->line('project_file_uploaded'):"project file uploaded."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Project status changed.</label>
                                    <input type="text" name="project_status_changed" value="<?=$this->lang->line('project_status_changed')?$this->lang->line('project_status_changed'):"Project status changed."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>new project created.</label>
                                    <input type="text" name="new_project_created" value="<?=$this->lang->line('new_project_created')?$this->lang->line('new_project_created'):"new project created."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>new invoice received.</label>
                                    <input type="text" name="new_invoice_received" value="<?=$this->lang->line('new_invoice_received')?$this->lang->line('new_invoice_received'):"new invoice received."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>task assigned you.</label>
                                    <input type="text" name="task_assigned_you" value="<?=$this->lang->line('task_assigned_you')?$this->lang->line('task_assigned_you'):"task assigned you."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>User registered successfully. Go to the login page and login with your credentials.</label>
                                    <input type="text" name="user_registered_successfully_go_to_the_login_page_and_login_with_your_credentials" value="<?=$this->lang->line('user_registered_successfully_go_to_the_login_page_and_login_with_your_credentials')?$this->lang->line('user_registered_successfully_go_to_the_login_page_and_login_with_your_credentials'):"User registered successfully. Go to the login page and login with your credentials."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Invalid User ID</label>
                                    <input type="text" name="invalid_user_id" value="<?=$this->lang->line('invalid_user_id')?$this->lang->line('invalid_user_id'):"Invalid User ID"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You must be an administrator to take this action.</label>
                                    <input type="text" name="you_must_be_an_administrator_to_take_this_action" value="<?=$this->lang->line('you_must_be_an_administrator_to_take_this_action')?$this->lang->line('you_must_be_an_administrator_to_take_this_action'):"You must be an administrator to take this action."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Access Denied</label>
                                    <input type="text" name="access_denied" value="<?=$this->lang->line('access_denied')?$this->lang->line('access_denied'):"Access Denied"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Something wrong! Try again.</label>
                                    <input type="text" name="something_wrong_try_again" value="<?=$this->lang->line('something_wrong_try_again')?$this->lang->line('something_wrong_try_again'):"Something wrong! Try again."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>ToDo deleted successfully.</label>
                                    <input type="text" name="todo_deleted_successfully" value="<?=$this->lang->line('todo_deleted_successfully')?$this->lang->line('todo_deleted_successfully'):"ToDo deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>ToDo updated successfully.</label>
                                    <input type="text" name="todo_updated_successfully" value="<?=$this->lang->line('todo_updated_successfully')?$this->lang->line('todo_updated_successfully'):"ToDo updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>ToDo created successfully.</label>
                                    <input type="text" name="todo_created_successfully" value="<?=$this->lang->line('todo_created_successfully')?$this->lang->line('todo_created_successfully'):"ToDo created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Tax deleted successfully.</label>
                                    <input type="text" name="tax_deleted_successfully" value="<?=$this->lang->line('tax_deleted_successfully')?$this->lang->line('tax_deleted_successfully'):"Tax deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Tax created successfully.</label>
                                    <input type="text" name="tax_created_successfully" value="<?=$this->lang->line('tax_created_successfully')?$this->lang->line('tax_created_successfully'):"Tax created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Tax updated successfully.</label>
                                    <input type="text" name="tax_updated_successfully" value="<?=$this->lang->line('tax_updated_successfully')?$this->lang->line('tax_updated_successfully'):"Tax updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Wrong update file is selected.</label>
                                    <input type="text" name="wrong_update_file_is_selected" value="<?=$this->lang->line('wrong_update_file_is_selected')?$this->lang->line('wrong_update_file_is_selected'):"Wrong update file is selected."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Select valid zip file.</label>
                                    <input type="text" name="select_valid_zip_file" value="<?=$this->lang->line('select_valid_zip_file')?$this->lang->line('select_valid_zip_file'):"Select valid zip file."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Error occured during file extracting. Select valid zip file OR Please Try again later.</label>
                                    <input type="text" name="error_occured_during_file_extracting_select_valid_zip_file_or_please_try_again_later" value="<?=$this->lang->line('error_occured_during_file_extracting_select_valid_zip_file_or_please_try_again_later')?$this->lang->line('error_occured_during_file_extracting_select_valid_zip_file_or_please_try_again_later'):"Error occured during file extracting. Select valid zip file OR Please Try again later."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Error occured during file uploading. Select valid zip file OR Please Try again later.</label>
                                    <input type="text" name="error_occured_during_file_uploading_select_valid_zip_file_or_please_try_again_later" value="<?=$this->lang->line('error_occured_during_file_uploading_select_valid_zip_file_or_please_try_again_later')?$this->lang->line('error_occured_during_file_uploading_select_valid_zip_file_or_please_try_again_later'):"Error occured during file uploading. Select valid zip file OR Please Try again later."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Payment Setting Saved.</label>
                                    <input type="text" name="payment_setting_saved" value="<?=$this->lang->line('payment_setting_saved')?$this->lang->line('payment_setting_saved'):"Payment Setting Saved."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Email Setting Saved.</label>
                                    <input type="text" name="email_setting_saved" value="<?=$this->lang->line('email_setting_saved')?$this->lang->line('email_setting_saved'):"Email Setting Saved."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>General Setting Saved.</label>
                                    <input type="text" name="general_setting_saved" value="<?=$this->lang->line('general_setting_saved')?$this->lang->line('general_setting_saved'):"General Setting Saved."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Company Setting Saved.</label>
                                    <input type="text" name="company_setting_saved" value="<?=$this->lang->line('company_setting_saved')?$this->lang->line('company_setting_saved'):"Company Setting Saved."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Permissions Setting Saved.</label>
                                    <input type="text" name="permissions_setting_saved" value="<?=$this->lang->line('permissions_setting_saved')?$this->lang->line('permissions_setting_saved'):"Permissions Setting Saved."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Frontend Setting Saved.</label>
                                    <input type="text" name="frontend_setting_saved" value="<?=$this->lang->line('frontend_setting_saved')?$this->lang->line('frontend_setting_saved'):"Frontend Setting Saved."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Project deleted successfully.</label>
                                    <input type="text" name="project_deleted_successfully" value="<?=$this->lang->line('project_deleted_successfully')?$this->lang->line('project_deleted_successfully'):"Project deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Project updated successfully.</label>
                                    <input type="text" name="project_updated_successfully" value="<?=$this->lang->line('project_updated_successfully')?$this->lang->line('project_updated_successfully'):"Project updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Project created successfully.</label>
                                    <input type="text" name="project_created_successfully" value="<?=$this->lang->line('project_created_successfully')?$this->lang->line('project_created_successfully'):"Project created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Task deleted successfully.</label>
                                    <input type="text" name="task_deleted_successfully" value="<?=$this->lang->line('task_deleted_successfully')?$this->lang->line('task_deleted_successfully'):"Task deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Task created successfully.</label>
                                    <input type="text" name="task_created_successfully" value="<?=$this->lang->line('task_created_successfully')?$this->lang->line('task_created_successfully'):"Task created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Task updated successfully.</label>
                                    <input type="text" name="task_updated_successfully" value="<?=$this->lang->line('task_updated_successfully')?$this->lang->line('task_updated_successfully'):"Task updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Comment created successfully.</label>
                                    <input type="text" name="comment_created_successfully" value="<?=$this->lang->line('comment_created_successfully')?$this->lang->line('comment_created_successfully'):"Comment created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Status updated successfully.</label>
                                    <input type="text" name="status_updated_successfully" value="<?=$this->lang->line('status_updated_successfully')?$this->lang->line('status_updated_successfully'):"Status updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>User deleted successfully.</label>
                                    <input type="text" name="user_deleted_successfully" value="<?=$this->lang->line('user_deleted_successfully')?$this->lang->line('user_deleted_successfully'):"User deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>System updated successfully.</label>
                                    <input type="text" name="system_updated_successfully" value="<?=$this->lang->line('system_updated_successfully')?$this->lang->line('system_updated_successfully'):"System updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>File deleted successfully.</label>
                                    <input type="text" name="file_deleted_successfully" value="<?=$this->lang->line('file_deleted_successfully')?$this->lang->line('file_deleted_successfully'):"File deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Plan deleted successfully.</label>
                                    <input type="text" name="plan_deleted_successfully" value="<?=$this->lang->line('plan_deleted_successfully')?$this->lang->line('plan_deleted_successfully'):"Plan deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Plan updated successfully.</label>
                                    <input type="text" name="plan_updated_successfully" value="<?=$this->lang->line('plan_updated_successfully')?$this->lang->line('plan_updated_successfully'):"Plan updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Plan created successfully.</label>
                                    <input type="text" name="plan_created_successfully" value="<?=$this->lang->line('plan_created_successfully')?$this->lang->line('plan_created_successfully'):"Plan created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Offline / Bank Transfer request sent successfully.</label>
                                    <input type="text" name="offline_bank_transfer_request_sent_successfully" value="<?=$this->lang->line('offline_bank_transfer_request_sent_successfully')?$this->lang->line('offline_bank_transfer_request_sent_successfully'):"Offline / Bank Transfer request sent successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>offline / bank transfer request accepted successfully.</label>
                                    <input type="text" name="offline_request_accepted_successfully" value="<?=$this->lang->line('offline_request_accepted_successfully')?$this->lang->line('offline_request_accepted_successfully'):"offline / bank transfer request accepted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>offline / bank transfer request rejected successfully.</label>
                                    <input type="text" name="offline_request_rejected_successfully" value="<?=$this->lang->line('offline_request_rejected_successfully')?$this->lang->line('offline_request_rejected_successfully'):"offline / bank transfer request rejected successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Payment unsuccessful. Please Try again later.</label>
                                    <input type="text" name="payment_unsuccessful_please_try_again_later" value="<?=$this->lang->line('payment_unsuccessful_please_try_again_later')?$this->lang->line('payment_unsuccessful_please_try_again_later'):"Payment unsuccessful. Please Try again later."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Payment successful.</label>
                                    <input type="text" name="payment_successful" value="<?=$this->lang->line('payment_successful')?$this->lang->line('payment_successful'):"Payment successful."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Bank transfer request received for the invoice</label>
                                    <input type="text" name="bank_transfer_request_received_for_the_invoice" value="<?=$this->lang->line('bank_transfer_request_received_for_the_invoice')?$this->lang->line('bank_transfer_request_received_for_the_invoice'):"Bank transfer request received for the invoice"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Bank transfer request accepted for the invoice</label>
                                    <input type="text" name="bank_transfer_request_accepted_for_the_invoice" value="<?=$this->lang->line('bank_transfer_request_accepted_for_the_invoice')?$this->lang->line('bank_transfer_request_accepted_for_the_invoice'):"Bank transfer request accepted for the invoice"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Bank transfer request rejected for the invoice</label>
                                    <input type="text" name="bank_transfer_request_rejected_for_the_invoice" value="<?=$this->lang->line('bank_transfer_request_rejected_for_the_invoice')?$this->lang->line('bank_transfer_request_rejected_for_the_invoice'):"Bank transfer request rejected for the invoice"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Payment received for the invoice</label>
                                    <input type="text" name="payment_received_for_the_invoice" value="<?=$this->lang->line('payment_received_for_the_invoice')?$this->lang->line('payment_received_for_the_invoice'):"Payment received for the invoice"?>" class="form-control">
                                </div>

                                <div class="form-group col-md-12">
                                    <label>Choose valid subscription plan.</label>
                                    <input type="text" name="choose_valid_subscription_plan" value="<?=$this->lang->line('choose_valid_subscription_plan')?$this->lang->line('choose_valid_subscription_plan'):"Choose valid subscription plan."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Plan subscribed successfully.</label>
                                    <input type="text" name="plan_subscribed_successfully" value="<?=$this->lang->line('plan_subscribed_successfully')?$this->lang->line('plan_subscribed_successfully'):"Plan subscribed successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Notification deleted successfully.</label>
                                    <input type="text" name="notification_deleted_successfully" value="<?=$this->lang->line('notification_deleted_successfully')?$this->lang->line('notification_deleted_successfully'):"Notification deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Note deleted successfully.</label>
                                    <input type="text" name="note_deleted_successfully" value="<?=$this->lang->line('note_deleted_successfully')?$this->lang->line('note_deleted_successfully'):"Note deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Note updated successfully.</label>
                                    <input type="text" name="note_updated_successfully" value="<?=$this->lang->line('note_updated_successfully')?$this->lang->line('note_updated_successfully'):"Note updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Note created successfully.</label>
                                    <input type="text" name="note_created_successfully" value="<?=$this->lang->line('note_created_successfully')?$this->lang->line('note_created_successfully'):"Note created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Only english characters allowed.</label>
                                    <input type="text" name="only_english_characters_allowed" value="<?=$this->lang->line('only_english_characters_allowed')?$this->lang->line('only_english_characters_allowed'):"Only english characters allowed."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Already exists this language.</label>
                                    <input type="text" name="already_exists_this_language" value="<?=$this->lang->line('already_exists_this_language')?$this->lang->line('already_exists_this_language'):"Already exists this language."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Language deleted successfully.</label>
                                    <input type="text" name="language_deleted_successfully" value="<?=$this->lang->line('language_deleted_successfully')?$this->lang->line('language_deleted_successfully'):"Language deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Language updated successfully.</label>
                                    <input type="text" name="language_updated_successfully" value="<?=$this->lang->line('language_updated_successfully')?$this->lang->line('language_updated_successfully'):"Language updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Language created successfully.</label>
                                    <input type="text" name="language_created_successfully" value="<?=$this->lang->line('language_created_successfully')?$this->lang->line('language_created_successfully'):"Language created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>We will get back to you soon.</label>
                                    <input type="text" name="we_will_get_back_to_you_soon" value="<?=$this->lang->line('we_will_get_back_to_you_soon')?$this->lang->line('we_will_get_back_to_you_soon'):"We will get back to you soon."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Feature deleted successfully.</label>
                                    <input type="text" name="feature_deleted_successfully" value="<?=$this->lang->line('feature_deleted_successfully')?$this->lang->line('feature_deleted_successfully'):"Feature deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Feature updated successfully.</label>
                                    <input type="text" name="feature_updated_successfully" value="<?=$this->lang->line('feature_updated_successfully')?$this->lang->line('feature_updated_successfully'):"Feature updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Pages updated successfully.</label>
                                    <input type="text" name="pages_updated_successfully" value="<?=$this->lang->line('pages_updated_successfully')?$this->lang->line('pages_updated_successfully'):"Pages updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Feature created successfully.</label>
                                    <input type="text" name="feature_created_successfully" value="<?=$this->lang->line('feature_created_successfully')?$this->lang->line('feature_created_successfully'):"Feature created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Chat deleted successfully.</label>
                                    <input type="text" name="chat_deleted_successfully" value="<?=$this->lang->line('chat_deleted_successfully')?$this->lang->line('chat_deleted_successfully'):"Chat deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Chat created successfully.</label>
                                    <input type="text" name="chat_created_successfully" value="<?=$this->lang->line('chat_created_successfully')?$this->lang->line('chat_created_successfully'):"Chat created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Wait...</label>
                                    <input type="text" name="wait" value="<?=$this->lang->line('wait')?$this->lang->line('wait'):"Wait..."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Default language can not be deleted.</label>
                                    <input type="text" name="default_language_can_not_be_deleted" value="<?=$this->lang->line('default_language_can_not_be_deleted')?$this->lang->line('default_language_can_not_be_deleted'):"Default language can not be deleted."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Are you sure?</label>
                                    <input type="text" name="are_you_sure" value="<?=$this->lang->line('are_you_sure')?$this->lang->line('are_you_sure'):"Are you sure?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this Notification?</label>
                                    <input type="text" name="you_want_to_delete_this_notification" value="<?=$this->lang->line('you_want_to_delete_this_notification')?$this->lang->line('you_want_to_delete_this_notification'):"You want to delete this Notification?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this Feature?</label>
                                    <input type="text" name="you_want_to_delete_this_feature" value="<?=$this->lang->line('you_want_to_delete_this_feature')?$this->lang->line('you_want_to_delete_this_feature'):"You want to delete this Feature?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want reject this offline / bank transfer request? This can not be undo.</label>
                                    <input type="text" name="you_want_reject_this_offline_request_this_can_not_be_undo" value="<?=$this->lang->line('you_want_reject_this_offline_request_this_can_not_be_undo')?$this->lang->line('you_want_reject_this_offline_request_this_can_not_be_undo'):"You want reject this offline / bank transfer request? This can not be undo."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want accept this offline / bank transfer request? This can not be undo.</label>
                                    <input type="text" name="you_want_accept_this_offline_request_this_can_not_be_undo" value="<?=$this->lang->line('you_want_accept_this_offline_request_this_can_not_be_undo')?$this->lang->line('you_want_accept_this_offline_request_this_can_not_be_undo'):"You want accept this offline / bank transfer request? This can not be undo."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Default plan can not be deleted.</label>
                                    <input type="text" name="default_plan_can_not_be_deleted" value="<?=$this->lang->line('default_plan_can_not_be_deleted')?$this->lang->line('default_plan_can_not_be_deleted'):"Default plan can not be deleted."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this Plan? All users under this plan will be added to the Default Plan.</label>
                                    <input type="text" name="you_want_to_delete_this_plan_all_users_under_this_plan_will_be_added_to_the_default_plan" value="<?=$this->lang->line('you_want_to_delete_this_plan_all_users_under_this_plan_will_be_added_to_the_default_plan')?$this->lang->line('you_want_to_delete_this_plan_all_users_under_this_plan_will_be_added_to_the_default_plan'):"You want to delete this Plan? All users under this plan will be added to the Default Plan."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this ToDo?</label>
                                    <input type="text" name="you_want_to_delete_this_todo" value="<?=$this->lang->line('you_want_to_delete_this_todo')?$this->lang->line('you_want_to_delete_this_todo'):"You want to delete this ToDo?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this note?</label>
                                    <input type="text" name="you_want_to_delete_this_note" value="<?=$this->lang->line('you_want_to_delete_this_note')?$this->lang->line('you_want_to_delete_this_note'):"You want to delete this note?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this project? All related data with this project also will be deleted.</label>
                                    <input type="text" name="you_want_to_delete_this_project_all_related_data_with_this_project_also_will_be_deleted" value="<?=$this->lang->line('you_want_to_delete_this_project_all_related_data_with_this_project_also_will_be_deleted')?$this->lang->line('you_want_to_delete_this_project_all_related_data_with_this_project_also_will_be_deleted'):"You want to delete this project? All related data with this project also will be deleted."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this task? All related data with this task also will be deleted.</label>
                                    <input type="text" name="you_want_to_delete_this_task_all_related_data_with_this_task_also_will_be_deleted" value="<?=$this->lang->line('you_want_to_delete_this_task_all_related_data_with_this_task_also_will_be_deleted')?$this->lang->line('you_want_to_delete_this_task_all_related_data_with_this_task_also_will_be_deleted'):"You want to delete this task? All related data with this task also will be deleted."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this user? All related data with this user also will be deleted.</label>
                                    <input type="text" name="you_want_to_delete_this_user_all_related_data_with_this_user_also_will_be_deleted" value="<?=$this->lang->line('you_want_to_delete_this_user_all_related_data_with_this_user_also_will_be_deleted')?$this->lang->line('you_want_to_delete_this_user_all_related_data_with_this_user_also_will_be_deleted'):"You want to delete this user? All related data with this user also will be deleted."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to upgrade the system? Please take a backup before going further.</label>
                                    <input type="text" name="you_want_to_upgrade_the_system_please_take_a_backup_before_going_further" value="<?=$this->lang->line('you_want_to_upgrade_the_system_please_take_a_backup_before_going_further')?$this->lang->line('you_want_to_upgrade_the_system_please_take_a_backup_before_going_further'):"You want to upgrade the system? Please take a backup before going further."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this file?</label>
                                    <input type="text" name="you_want_to_delete_this_file" value="<?=$this->lang->line('you_want_to_delete_this_file')?$this->lang->line('you_want_to_delete_this_file'):"You want to delete this file?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to activate this user?</label>
                                    <input type="text" name="you_want_to_activate_this_user" value="<?=$this->lang->line('you_want_to_activate_this_user')?$this->lang->line('you_want_to_activate_this_user'):"You want to activate this user?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to deactivate this user? This user will be not able to login after deactivation.</label>
                                    <input type="text" name="you_want_to_deactivate_this_user_this_user_will_be_not_able_to_login_after_deactivation" value="<?=$this->lang->line('you_want_to_deactivate_this_user_this_user_will_be_not_able_to_login_after_deactivation')?$this->lang->line('you_want_to_deactivate_this_user_this_user_will_be_not_able_to_login_after_deactivation'):"You want to deactivate this user? This user will be not able to login after deactivation."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this chat? This can not be undo.</label>
                                    <input type="text" name="you_want_to_delete_this_chat_this_can_not_be_undo" value="<?=$this->lang->line('you_want_to_delete_this_chat_this_can_not_be_undo')?$this->lang->line('you_want_to_delete_this_chat_this_can_not_be_undo'):"You want to delete this chat? This can not be undo."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>We will contact you for further process of payment as soon as possible. Click OK to confirm.</label>
                                    <input type="text" name="we_will_contact_you_for_further_process_of_payment_as_soon_as_possible_click_ok_to_confirm" value="<?=$this->lang->line('we_will_contact_you_for_further_process_of_payment_as_soon_as_possible_click_ok_to_confirm')?$this->lang->line('we_will_contact_you_for_further_process_of_payment_as_soon_as_possible_click_ok_to_confirm'):"We will contact you for further process of payment as soon as possible. Click OK to confirm."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Currency code need as per three letter ISO code.</label>
                                    <input type="text" name="currency_code_need_as_per_three_letter_iso_code" value="<?=$this->lang->line('currency_code_need_as_per_three_letter_iso_code')?$this->lang->line('currency_code_need_as_per_three_letter_iso_code'):"Currency code need as per three letter ISO code. Make sure payment gateways supporting this currency."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>This details will be used as billing details.</label>
                                    <input type="text" name="this_details_will_be_used_as_billing_details" value="<?=$this->lang->line('this_details_will_be_used_as_billing_details')?$this->lang->line('this_details_will_be_used_as_billing_details'):"This details will be used as billing details."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this Language?</label>
                                    <input type="text" name="you_want_to_delete_this_language" value="<?=$this->lang->line('you_want_to_delete_this_language')?$this->lang->line('you_want_to_delete_this_language'):"You want to delete this Language?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this Tax?</label>
                                    <input type="text" name="you_want_to_delete_this_tax" value="<?=$this->lang->line('you_want_to_delete_this_tax')?$this->lang->line('you_want_to_delete_this_tax'):"You want to delete this Tax?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>You want to delete this Invoice?</label>
                                    <input type="text" name="you_want_to_delete_this_invoice" value="<?=$this->lang->line('you_want_to_delete_this_invoice')?$this->lang->line('you_want_to_delete_this_invoice'):"You want to delete this Invoice?"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Invoice deleted successfully.</label>
                                    <input type="text" name="invoice_deleted_successfully" value="<?=$this->lang->line('invoice_deleted_successfully')?$this->lang->line('invoice_deleted_successfully'):"Invoice deleted successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Invoice created successfully.</label>
                                    <input type="text" name="invoice_created_successfully" value="<?=$this->lang->line('invoice_created_successfully')?$this->lang->line('invoice_created_successfully'):"Invoice created successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Invoice updated successfully.</label>
                                    <input type="text" name="invoice_updated_successfully" value="<?=$this->lang->line('invoice_updated_successfully')?$this->lang->line('invoice_updated_successfully'):"Invoice updated successfully."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>We couldn't find any data</label>
                                    <input type="text" name="we_couldnt_find_any_data" value="<?=$this->lang->line('we_couldnt_find_any_data')?$this->lang->line('we_couldnt_find_any_data'):"We couldn't find any data"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Ending date should not be less then starting date.</label>
                                    <input type="text" name="ending_date_should_not_be_less_then_starting_date" value="<?=$this->lang->line('ending_date_should_not_be_less_then_starting_date')?$this->lang->line('ending_date_should_not_be_less_then_starting_date'):"Ending date should not be less then starting date."?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Created successfully.</label>
                                    <input type="text" name="created_successfully" value="<?=$this->lang->line('created_successfully')?$this->lang->line('created_successfully'):"Created successfully"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Updated successfully.</label>
                                    <input type="text" name="updated_successfully" value="<?=$this->lang->line('updated_successfully')?$this->lang->line('updated_successfully'):"Updated successfully"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Deleted successfully.</label>
                                    <input type="text" name="deleted_successfully" value="<?=$this->lang->line('deleted_successfully')?$this->lang->line('deleted_successfully'):"Deleted successfully"?>" class="form-control">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>Timer already running on this task</label>
                                    <input type="text" name="timer_already_running_on_this_task" value="<?=$this->lang->line('timer_already_running_on_this_task')?$this->lang->line('timer_already_running_on_this_task'):"Timer already running on this task"?>" class="form-control">
                                </div>
                              
                                <div class="form-group col-md-6">
                                    <label>Storage Limit Exceeded</label>
                                    <input type="text" name="storage_limit_exceeded" value="<?=$this->lang->line('storage_limit_exceeded')?$this->lang->line('storage_limit_exceeded'):'Storage Limit Exceeded'?>" class="form-control">
                                </div>

                            </div>
                            <div class="card-footer bg-whitesmoke text-md-right">
                                <button class="btn btn-primary savebtn"><?=$this->lang->line('save_changes')?$this->lang->line('save_changes'):'Save Changes'?></button>
                            </div>
                            <div class="result"></div>
                        </form>
                    </div>
                </div>




              </div>
            </div>
          </section>
        </div>
      <?php $this->load->view('includes/footer'); ?>
    </div>
  </div>

<?php $this->load->view('includes/js'); ?>
</body>
</html>
