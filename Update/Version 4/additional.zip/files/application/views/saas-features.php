<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('includes/head'); ?>
</head>
<body>
  <div id="app">
    <div class="main-wrapper">
      <?php $this->load->view('includes/navbar'); ?>
        <div class="main-content">
          <section class="section">
            <div class="section-header">
              <div class="section-header-back">
                <a href="<?=base_url()?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
              </div>
              <h1><?=$this->lang->line('frontend')?$this->lang->line('frontend'):'Frontend'?></h1>
              <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?=base_url()?>"><?=$this->lang->line('dashboard')?$this->lang->line('dashboard'):'Dashboard'?></a></div>
                <div class="breadcrumb-item"><?=$this->lang->line('frontend')?$this->lang->line('frontend'):'Frontend'?></div>
              </div>
            </div>

            <div class="section-body">
              <div class="row">
              
                <div class="col-md-3">
                  <div class="card card-primary">
                    <div class="card-body">
                      <ul class="nav nav-pills flex-column">
                        <li class="nav-item"><a href="<?=base_url('front/landing')?>" class="nav-link"><?=$this->lang->line('general')?$this->lang->line('general'):'General'?></a></li>
                        <li class="nav-item"><a href="<?=base_url('front/home')?>" class="nav-link"><?=$this->lang->line('home')?$this->lang->line('home'):'Home'?></a></li>
                        <li class="nav-item"><a href="<?=base_url('front/features')?>" class="nav-link active"><?=$this->lang->line('features')?$this->lang->line('features'):'Features'?></a></li>
                        <li class="nav-item"><a href="<?=base_url('front/about')?>" class="nav-link"><?=$this->lang->line('about')?$this->lang->line('about'):'About Us'?></a></li>
                        <li class="nav-item"><a href="<?=base_url('front/saas-privacy-policy')?>" class="nav-link"><?=$this->lang->line('privacy_policy')?$this->lang->line('privacy_policy'):'Privacy Policy'?></a></li>
                        <li class="nav-item"><a href="<?=base_url('front/saas-terms-and-conditions')?>" class="nav-link"><?=$this->lang->line('terms_and_conditions')?$this->lang->line('terms_and_conditions'):'Terms and Conditions'?></a></li>
                      </ul>
                    </div>
                  </div>
                </div>


                <div class="col-md-9" id="feature_div">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h4 class="card-title"><?=$this->lang->line('features')?$this->lang->line('features'):'Features'?> </h4>

                      <div class="card-header-action dropdown">
                        <a href="<?=base_url('front/create-feature')?>" class="btn btn-primary"><?=$this->lang->line('create')?$this->lang->line('create'):'Create'?></a>
                        
                      </div>
                    </div>
                    <div class="card-body">
                      <table class='table-striped' id='features_list'
                          data-toggle="table"
                          data-url="<?=base_url('front/get_feature')?>"
                          data-click-to-select="true"
                          data-side-pagination="server"
                          data-pagination="false"
                          data-page-list="[5, 10, 20, 50, 100, 200]"
                          data-search="false" data-show-columns="false"
                          data-show-refresh="false" data-trim-on-search="false"
                          data-sort-name="id" data-sort-order="asc"
                          data-mobile-responsive="true"
                          data-toolbar="" data-show-export="false"
                          data-maintain-selected="true"
                          data-export-types='["txt","excel"]'
                          data-export-options='{
                            "fileName": "features-list",
                            "ignoreColumn": ["state"] 
                          }'
                          data-query-params="queryParams">
                          <thead>
                            <tr>
                              <th data-field="title" data-sortable="true"><?=$this->lang->line('title')?$this->lang->line('title'):'Title'?></th>
                              <th data-field="description" data-sortable="true"><?=$this->lang->line('description')?$this->lang->line('description'):'Description'?></th>
                              <th data-field="icon" data-sortable="true"><?=$this->lang->line('icon')?$this->lang->line('icon'):'Icon'?></th>
                              <th data-field="action" data-sortable="false"><?=$this->lang->line('action')?$this->lang->line('action'):'Action'?></th>
                            </tr>
                          </thead>
                      </table>
                    </div>
                  </div>
                </div>



              </div>
            </div>
          </section>
        </div>
      <?php $this->load->view('includes/footer'); ?>
    </div>
  </div>

  <form action="<?=base_url('front/edit-pages')?>" method="POST" class="modal-part" id="modal-edit-pages-part" data-title="<?=$this->lang->line('edit')?$this->lang->line('edit'):'Edit'?>" data-btn_update="<?=$this->lang->line('update')?$this->lang->line('update'):'Update'?>">
  <input type="hidden" name="update_id" id="update_id" value="">
  <div class="row">
    <div class="form-group col-md-12">
      <label><?=$this->lang->line('pages_content')?$this->lang->line('pages_content'):'Page Content'?> (HTML)<span class="text-danger">*</span></label>
      <textarea type="text" name="content" id="content" class="form-control"></textarea>
    </div>
  </div>
</form>
<div id="modal-edit-pages"></div>

<?php $this->load->view('includes/js'); ?>
</body>
</html>
