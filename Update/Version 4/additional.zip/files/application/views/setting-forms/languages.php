<form action="<?=base_url('languages/create')?>" method="POST" id="language-form" enctype="multipart/form-data">

  <div class="card-body row">
    
    <div class="p-0 d-flex col-md-12">
        <input type="text" name="language" id="language" class="form-control" placeholder="<?=$this->lang->line('language_name')?$this->lang->line('language_name'):'Language name'?>" required>
        <button type="submit" class="btn btn-primary savebtn">
        <?=$this->lang->line('create')?$this->lang->line('create'):'Create'?>
        </button>
    </div>

    <div class="col-md-12">
      <table class='table-striped' id='languages_list'
        data-toggle="table"
        data-url="<?=base_url('languages/get_languages')?>"
        data-click-to-select="true"
        data-side-pagination="server"
        data-pagination="false"
        data-page-list="[5, 10, 20, 50, 100, 200]"
        data-search="false" data-show-columns="false"
        data-show-refresh="false" data-trim-on-search="false"
        data-sort-name="id" data-sort-order="asc"
        data-mobile-responsive="true"
        data-toolbar="" data-show-export="false"
        data-maintain-selected="true"
        data-export-types='["txt","excel"]'
        data-export-options='{
          "fileName": "languages-list",
          "ignoreColumn": ["state"] 
        }'
        data-query-params="queryParams">
        <thead>
          <tr>
            <th data-field="language" data-sortable="true"><?=$this->lang->line('languages')?$this->lang->line('languages'):'Languages'?></th>
            <th data-field="action" data-sortable="false"><?=$this->lang->line('action')?$this->lang->line('action'):'Action'?></th>
          </tr>
        </thead>
      </table>
    </div>


  </div>
  <div class="result"></div>
</form>